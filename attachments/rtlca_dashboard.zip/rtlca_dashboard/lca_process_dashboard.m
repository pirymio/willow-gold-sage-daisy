
function lca_process_dashboard()
% =========================================================================
%  RT-LCA / LCC PROCESS DASHBOARD  -  entry point (modular version)
% -------------------------------------------------------------------------
%  Run from this folder:  lca_process_dashboard
%  Nine files, one per phase of the framework (see README.md):
%    rtlca_ui.m        interface, accordion navigation, process map
%    rtlca_system.m    Module 1: unit processes, flows, taxonomy rules
%    rtlca_costs.m     LCC cost window
%    rtlca_sources.m   Modules 2/5: acquisition file, grid mix, price, confirm
%    rtlca_engine.m    Modules 5-6-7: cycle engine (LCI, LCIA, LCC, CED)
%    rtlca_io.m        file readers
%    rtlca_persist.m   Module 4: log and results persistence (Excel + MAT)
%    rtlca_util.m      shared helpers
%  Modules are called as  rtlca_<module>('functionName', args...).
% -------------------------------------------------------------------------
%  WORKFLOW (six guided steps, one open at a time):
%   1 Database   2 System definition   3 Flows (LCI)   4 Costs (LCC)
%   5 RT source, grid mix, price + CONFIRM   6 Run the campaign + SAVE RESULTS
%  RESULT TABS: MAP, IMPACT, ENERGY, PARETO, LCC, CED
% =========================================================================

scr = get(0,'ScreenSize');
BW = 1530; BH = 900;
z  = min(1, min((scr(3)-30)/BW, (scr(4)-90)/BH));
W  = round(BW*z); H = round(BH*z);
fig = uifigure('Name','RT-LCA Process Dashboard', ...
               'Position',[round((scr(3)-W)/2) round((scr(4)-H)/2)+20 W H], ...
               'Color',[1 1 1]);
fig.CloseRequestFcn = @(s,e) rtlca_engine('onClose',s,e);

S = struct();
S.Z = z;
S.Loaded=false; S.ProcsDone=false; S.FlowsDone=false; S.ConfigDone=false;
S.Procs = {};                      % unit-process names, flow order
S.Inputs = rtlca_util('newInputTemplate'); S.Inputs(1) = [];
S.ExpN=0; S.Campaign=''; S.RTLoaded=false;
S.Idx=1; S.TOffset=0; S.RtList=[];
S.HotN=0; S.MaxStep=1;
S.Results=struct([]); S.Series={}; S.Rec=[];   % persistence (Module 4): cycle summaries + per-instant series
S.MixLoaded=false; S.MixT=[]; S.MixSrc={}; S.MixGen=[]; S.MixCf=[];
S.MixStart=NaN; S.CfMixVec=[]; S.ShareVec=[];
S.CedCol=0; S.CedNRcols=[]; S.CedRcols=[]; S.MixCed=[]; S.CedMixVec=[];
S.CostsSet=false; S.CostP=[]; S.EnergyBill=0.25; S.CarbonPrice=0; S.DisrCost=0; S.UnitsPerCycle=1;
S.PriceLoaded=false; S.PriceT=[]; S.PriceKWh=[]; S.PriceVec=[];
setappdata(fig,'S',S);
setappdata(fig,'RUN',false);

rtlca_ui('buildUI', fig);
rtlca_ui('gotoStep', fig,1);
rtlca_ui('showTab', fig,1);
end % ====================================================================


% #########################################################################
%  UI
% #########################################################################
