function varargout = rtlca_util(action, varargin)
% rtlca_util  -  RT-LCA dashboard module: shared helpers: text, unit conversion, taxonomy accessors, templates
% Call as  rtlca_util('functionName', args...)  : dispatches to the local function.
% Functions: trunc, energy_toMJ, curData, curTipo, newInputTemplate, costItemNames
f = str2func(action);
[varargout{1:nargout}] = f(varargin{:});
end


function s = trunc(s, n)
if numel(s) > n, s = s(1:n); end
end


function f = energy_toMJ(u)
switch lower(strtrim(u))
    case 'j',   f = 1e-6;
    case 'kj',  f = 1e-3;
    case 'mj',  f = 1;
    case 'gj',  f = 1e3;
    case 'wh',  f = 0.0036;
    case 'kwh', f = 3.6;
    case 'mwh', f = 3600;
    otherwise,  f = NaN;
end
end


function dt = curData(S)
dt = S.BGData.SelectedObject.Text;
end


function tp = curTipo(S)
tp = S.BGTipo.SelectedObject.Text;
end


function s = newInputTemplate()
s = struct('Nome','', 'Tipo','', 'Proc',1, 'Dir','Input', 'Price',0, 'CedF',[0 0], ...
           'ProcIdx',0, 'RowSheet',0, 'Unit','', ...
           'Qty',0, 'ColIdx',0, 'Cf',0, 'CfLabel','', 'DataType','', ...
           'LawTxt','', 'LawFun',[], 'RTCol',0, 'RTColName','', 'RTConv',1);
end


% #########################################################################
%  TABS AND STEPS
% #########################################################################


function [names, units] = costItemNames()
% Hourly cost items of a unit process (Environmental LCC, gate-to-gate):
%  capital costs: machine depreciation, tooling/dies amortisation
%  operating costs: labour, planned maintenance, auxiliary utilities,
%                   consumables, allocated overheads
names = {'Machine depreciation (CAPEX)', 'Tooling / dies amortisation', ...
         'Labour (operators)', 'Planned maintenance', ...
         'Auxiliary utilities (air, water, cooling)', 'Consumables (lubricants, cleaning)', ...
         'Allocated overheads (indirect)'};
units = repmat({'EUR/h'}, 1, numel(names));
end


