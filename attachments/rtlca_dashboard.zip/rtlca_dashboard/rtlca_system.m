function varargout = rtlca_system(action, varargin)
% rtlca_system  -  RT-LCA dashboard module: Module 1 - system definition: unit processes, flows and taxonomy rules, inspection dialog
% Call as  rtlca_system('functionName', args...)  : dispatches to the local function.
% Functions: onLoadDb, onAddProc, onDelProc, onProcsNext, onDataTypeChanged, onTipoChanged, onLawType, buildLaw, onFilter, applyFilter, onProcChanged, onAddInput, onRemoveInput, refreshList, onEndFlows, onBlockClick, onFlowClick, invalidateConfig, openProcDialog, fillProcDialog, procSelect, procEdit, procRemove, procRename, procAddFlow, procCosts, ced_factors
f = str2func(action);
[varargout{1:nargout}] = f(varargin{:});
end


function onLoadDb(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
fd = rtlca_io('resolve_file', S.EFDb.Value,'COEFFICIENT database');
if isempty(fd), return; end
S.EFDb.Value = fd;
d = uiprogressdlg(fig,'Title','Loading','Message','Reading database...','Indeterminate','on');
try
    [S.DbRaw, S.CoefCols, S.ColLabels, S.ProcNames, S.ProcUnits, S.ProcRow] = rtlca_io('read_db', fd);
    S.DDImpG.Items = S.ColLabels; S.DDImpG.ItemsData = 1:numel(S.ColLabels); S.DDImpG.Value = 1;
    S.Loaded = true;
    % CED columns of the dataset: total + six sub-columns (raw columns after it)
    S.CedCol = 0; S.CedNRcols = []; S.CedRcols = [];
    for c = 1:numel(S.ColLabels)
        if strncmpi(strtrim(S.ColLabels{c}),'CED',3), S.CedCol = c; break; end
    end
    if S.CedCol > 0
        c0 = S.CoefCols(S.CedCol);
        for c = 1:numel(S.ColLabels)
            if S.CoefCols(c) > c0 && S.CoefCols(c) <= c0+6
                if strncmpi(strtrim(S.ColLabels{c}),'Non-renewable',13), S.CedNRcols(end+1) = c; %#ok<AGROW>
                elseif strncmpi(strtrim(S.ColLabels{c}),'Renewable',9), S.CedRcols(end+1) = c; end %#ok<AGROW>
            end
        end
        rtlca_persist('addLog', fig, sprintf('CED columns found: total + %d non-renewable + %d renewable', ...
               numel(S.CedNRcols), numel(S.CedRcols)));
    else
        rtlca_persist('addLog', fig,'WARNING: no CED column in the dataset (CED tab disabled).');
    end
    S.LblStatus.Text = sprintf('Database loaded: %d processes, %d indicators. Define the system.', ...
                               numel(S.ProcNames), numel(S.ColLabels));
    setappdata(fig,'S',S);
    rtlca_ui('gotoStep', fig,2);
catch ME
    uialert(fig, ME.message, 'Loading error');
end
if isvalid(d), delete(d); end
end


% #########################################################################
%  STEP 2: SYSTEM DEFINITION (unit processes)
% #########################################################################


function onAddProc(src,~)
% "+" : asks the name of the new unit process and appends it to the chain.
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
n = numel(S.Procs) + 1;
answ = inputdlg({sprintf('Name of unit process #%d (downstream of the previous one):', n)}, ...
                'Add unit process', 1, {sprintf('Process_%d', n)});
if isempty(answ) || isempty(strtrim(answ{1})), return; end
S.Procs{end+1} = strtrim(answ{1});
S.LblChain.Text = strjoin(S.Procs,'  >  ');
S.DDProcU.Items = S.Procs; S.DDProcU.ItemsData = 1:numel(S.Procs); S.DDProcU.Value = numel(S.Procs);
setappdata(fig,'S',S);
rtlca_ui('drawMap', fig, []);
S = getappdata(fig,'S');
S.LblStatus.Text = sprintf('%d unit processes: press + for another one, NEXT to add the flows.', numel(S.Procs));
setappdata(fig,'S',S);
end


function onDelProc(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
n = numel(S.Procs);
if n == 0, return; end
if ~isempty(S.Inputs) && any([S.Inputs.Proc] == n)
    uialert(fig,sprintf('"%s" has flows: remove them first.', S.Procs{n}),'Unit processes'); return;
end
S.Procs(n) = [];
if isempty(S.Procs)
    S.LblChain.Text = '(no processes yet: press +)';
    S.DDProcU.Items = {'(define processes)'}; S.DDProcU.ItemsData = [];
    cla(S.AxMap);
else
    S.LblChain.Text = strjoin(S.Procs,'  >  ');
    S.DDProcU.Items = S.Procs; S.DDProcU.ItemsData = 1:numel(S.Procs); S.DDProcU.Value = numel(S.Procs);
end
setappdata(fig,'S',S);
if ~isempty(S.Procs), rtlca_ui('drawMap', fig, []); end
end


function onProcsNext(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if isempty(S.Procs)
    uialert(fig,'Add at least one unit process with the + button.','Unit processes'); return;
end
S.ProcsDone = true;
setappdata(fig,'S',S);
rtlca_ui('gotoStep', fig,3);
S = getappdata(fig,'S');
S.LblStatus.Text = 'Now add the input/output flows of each unit process (energy: one real-time flow per process).';
setappdata(fig,'S',S);
if S.Loaded, applyFilter(fig); end
end


function onDataTypeChanged(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
before = rtlca_util('curTipo', S);
if strcmp(rtlca_util('curData', S),'real-time'), S.BGTipo.SelectedObject = S.RbEne;
else, S.BGTipo.SelectedObject = S.RbMat; end
setappdata(fig,'S',S);
rtlca_ui('syncZone', fig);
if ~strcmp(before, rtlca_util('curTipo', S)), applyFilter(fig); end   % rebuild the menu only if needed
end


function onTipoChanged(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if strcmp(rtlca_util('curTipo', S),'Energy')
    S.BGData.SelectedObject = S.RbRT;
elseif strcmp(rtlca_util('curData', S),'real-time')
    S.BGData.SelectedObject = S.RbStat;
end
setappdata(fig,'S',S);
rtlca_ui('syncZone', fig);
applyFilter(fig);
end


function onLawType(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if strncmpi(S.DDLaw.Value,'Custom',6), S.EFexpr.Enable = 'on';
else, S.EFexpr.Enable = 'off'; end
setappdata(fig,'S',S);
end


function [f, txt, msg] = buildLaw(S)
f = []; txt = ''; msg = '';
a = S.EFa.Value; b = S.EFb.Value; w = S.EFw.Value;
law = S.DDLaw.Value;
switch law(1:3)
    case 'Lin'
        if b == 0, msg = 'b = 0 makes the law CONSTANT: not allowed.'; return; end
        f = @(t) a + b*t;  txt = sprintf('%.6g + %.6g*t', a, b);
    case 'Sin'
        if b == 0 || w == 0, msg = 'b = 0 or w = 0 make the law CONSTANT.'; return; end
        f = @(t) a + b*sin(w*t);  txt = sprintf('%.6g + %.6g*sin(%.6g*t)', a, b, w);
    case 'Exp'
        if a == 0 || b == 0, msg = 'a = 0 or b = 0 make the law CONSTANT.'; return; end
        f = @(t) a*exp(b*t);  txt = sprintf('%.6g*exp(%.6g*t)', a, b);
    otherwise
        expr = strtrim(S.EFexpr.Value);
        if isempty(expr), msg = 'Write an expression f(t).'; return; end
        try
            f0 = str2func(['@(t) ' expr]);
            tt = linspace(0,100,201);
            y  = arrayfun(@(x) f0(x), tt);
        catch
            msg = 'Invalid expression: use the variable t.'; return;
        end
        if any(~isfinite(y)), msg = 'Non-finite values on [0,100].'; return; end
        if (max(y)-min(y)) <= 1e-9*(1+max(abs(y)))
            msg = 'The expression is CONSTANT: not allowed for a dynamic datum.'; return;
        end
        f = f0; txt = expr;
end
end


function onFilter(src,~)
applyFilter(ancestor(src,'figure'));
end


function applyFilter(fig)
S = getappdata(fig,'S');
if ~S.Loaded, return; end
if strcmp(rtlca_util('curTipo', S),'Energy'), m = strcmpi(S.ProcUnits,'MJ');
else, m = true(1,numel(S.ProcNames)); end
kw = strtrim(S.EFKw.Value);
if ~isempty(kw)
    keep = false(1,numel(S.ProcNames));
    for i = 1:numel(S.ProcNames)
        keep(i) = ~isempty(strfind(lower(S.ProcNames{i}), lower(kw))); %#ok<STREMP>
    end
    m = m & keep;
end
idx = find(m);
if isempty(idx)
    S.DDProc.Items = {'(no result: change the filter)'}; S.DDProc.ItemsData = [];
    S.LblQty.Text = 'Quantity:';
    setappdata(fig,'S',S); return;
end
% a dropdown with thousands of entries is slow to build: cap the list and
% tell the user to type a filter (the filter searches the WHOLE dataset)
MAXITEMS = 250;
nAll = numel(idx);
if nAll > MAXITEMS
    idx = idx(1:MAXITEMS);
    S.LblStatus.Text = sprintf('%d dataset processes match: showing the first %d - type a word in "filter" to narrow.', nAll, MAXITEMS);
end
lab = cell(1,numel(idx));
for i = 1:numel(idx)
    lab{i} = sprintf('%s  [%s | row %d]', S.ProcNames{idx(i)}, S.ProcUnits{idx(i)}, S.ProcRow(idx(i)));
end
S.DDProc.Items = lab; S.DDProc.ItemsData = idx; S.DDProc.Value = idx(1);
setappdata(fig,'S',S);
onProcChanged(S.DDProc,[]);
end


function onProcChanged(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
ip = S.DDProc.Value;
if ~isnumeric(ip) || isempty(ip) || ip < 1, return; end
S.LblQty.Text = sprintf('Quantity (%s):', S.ProcUnits{ip});
setappdata(fig,'S',S);
end


function onAddInput(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if ~S.ProcsDone
    uialert(fig,'Define the unit processes first (Step 2).','Flows'); return;
end
ip = S.DDProc.Value; ic = S.DDImpG.Value;
if ~isnumeric(ip) || isempty(ip)
    uialert(fig,'Select a valid dataset process.','Flows'); return;
end
v = S.DbRaw{ S.ProcRow(ip), S.CoefCols(ic) };
if ~rtlca_io('is_num', v)
    uialert(fig,'Non-numeric coefficient for this row in the chosen category.','Flows'); return;
end
dt = rtlca_util('curData', S);
in = rtlca_util('newInputTemplate');
in.Nome = S.ProcNames{ip};  in.Tipo = rtlca_util('curTipo', S);
in.Proc = S.DDProcU.Value;
if S.RbOut.Value, in.Dir = 'Output'; else, in.Dir = 'Input'; end
in.ProcIdx = ip;            in.RowSheet = S.ProcRow(ip);
in.Unit = S.ProcUnits{ip};  in.ColIdx = ic;
in.Cf = double(v);          in.CfLabel = S.ColLabels{ic};
in.DataType = dt;
in.CedF = ced_factors(S, ip);
switch dt
    case {'static','quasi-static'}
        if ~isfinite(S.EFQty.Value)
            uialert(fig,'Invalid quantity.','Flows'); return;
        end
        in.Qty = S.EFQty.Value;
    case 'dynamic'
        [f, txt, msg] = buildLaw(S);
        if ~isempty(msg), uialert(fig, msg, 'Variation law'); return; end
        in.LawFun = f; in.LawTxt = txt;
        in.Qty = NaN;
    otherwise
        % one energy (real-time) input PER UNIT PROCESS: at load, each energy
        % column of the file is matched to the energy input of a process
        if any(strcmp({S.Inputs.DataType},'real-time') & [S.Inputs.Proc] == in.Proc)
            uialert(fig,sprintf(['"%s" already has its energy input: one per unit ' ...
                'process (a second one would double-count the same column).'], ...
                S.Procs{in.Proc}),'Real-time'); return;
        end
        in.Qty = NaN;
end
S.Inputs(end+1) = in;
S.DDImpG.Enable = 'off';       % category is fixed once the LCI starts (ISO consistency)
setappdata(fig,'S',S);
refreshList(fig);
rtlca_ui('drawMap', fig, []);
S = getappdata(fig,'S');
S.LblStatus.Text = sprintf('%d flows defined. Press FINISH FLOWS when done.', numel(S.Inputs));
setappdata(fig,'S',S);
end


function onRemoveInput(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
r = S.LstIn.Value;
if ~isnumeric(r) || isempty(r) || r < 1 || r > numel(S.Inputs)
    uialert(fig,'Select a flow in the list.','Remove'); return;
end
S.Inputs(r) = [];
if isempty(S.Inputs), S.DDImpG.Enable = 'on'; end
setappdata(fig,'S',S);
refreshList(fig);
rtlca_ui('drawMap', fig, []);
end


function refreshList(fig)
S = getappdata(fig,'S');
n = numel(S.Inputs);
if n == 0
    S.LstIn.Items = {'(no flows yet)'}; S.LstIn.ItemsData = [];
else
    it = cell(1,n);
    for i = 1:n
        in = S.Inputs(i);
        if strcmp(in.DataType,'dynamic'), q = ['v(t)=' rtlca_util('trunc', in.LawTxt,12)];
        elseif isnan(in.Qty), q = 'from source';
        else, q = sprintf('%.4g %s', in.Qty, in.Unit); end
        it{i} = sprintf('#%d [%s|%s] %s | %s | %s', i, rtlca_util('trunc', S.Procs{in.Proc},8), ...
                        in.Dir(1:2), rtlca_util('trunc', in.Nome,16), in.DataType, q);
    end
    S.LstIn.Items = it; S.LstIn.ItemsData = 1:n; S.LstIn.Value = n;
end
setappdata(fig,'S',S);
end


function onEndFlows(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if isempty(S.Inputs)
    uialert(fig,'Define at least one flow.','Finish flows'); return;
end
for p = 1:numel(S.Procs)
    if ~any([S.Inputs.Proc] == p)
        rtlca_persist('addLog', fig, sprintf('WARNING: process "%s" has no flows (empty column in Pareto).', S.Procs{p}));
    end
end
S.RtList = find(strcmp({S.Inputs.DataType},'real-time'));
S.FlowsDone = true;
setappdata(fig,'S',S);
rtlca_ui('gotoStep', fig,4);
S = getappdata(fig,'S');
S.LblStatus.Text = 'Enter the costs and prices for the LCC (or NEXT to skip them).';
setappdata(fig,'S',S);
end


% #########################################################################
%  STEP 4: COSTS AND PRICES (LCC)  -  economic data taxonomy of the thesis
% -------------------------------------------------------------------------
%   static / quasi-static (economic): unit prices of material flows from the
%       ERP [EUR per flow unit], disposal/treatment cost of output flows
%       [EUR per unit], hourly machine depreciation (CAPEX) and labour cost
%       of every unit process [EUR/h], energy price from the bill [EUR/kWh]
%   dynamic (economic): flows modelled by v(t) are priced on the model value
%   real-time (economic): 15-min energy price file (LOAD PRICE, Step 5);
%       when loaded it replaces the bill price instant by instant
%   Cost(t) = sum_j g_j(t) * UnitCost_j(t): instantaneous and cumulative
% #########################################################################


function onBlockClick(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if getappdata(fig,'RUN'), return; end
p = src.UserData;
if isnumeric(S.DDProcU.ItemsData) && any(S.DDProcU.ItemsData == p), S.DDProcU.Value = p; end
setappdata(fig,'S',S);
openProcDialog(fig, p, 0);
end


function onFlowClick(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if getappdata(fig,'RUN'), return; end
i = src.UserData;
if i < 1 || i > numel(S.Inputs), return; end
openProcDialog(fig, S.Inputs(i).Proc, i);
end


function invalidateConfig(fig, why)
S = getappdata(fig,'S');
if S.ConfigDone
    S.ConfigDone = false;
    rtlca_persist('addLog', fig, ['Configuration changed (' why '): press CONFIRM (Step 5) again before running.']);
    S.LblStatus.Text = 'Configuration changed: CONFIRM again before START.';
end
setappdata(fig,'S',S);
end


function openProcDialog(fig, p, selFlow)
% Inspector of a unit process: name (editable), position in the chain,
% hourly costs, and the table of its flows with editable quantity (static /
% quasi-static) and unit price. Shortcuts to add flows and edit costs.
S = getappdata(fig,'S');
scr = get(0,'ScreenSize'); z = S.Z;
Wd = round(860*z); Hd = round(520*z);
if selFlow > 0, ttl = sprintf('Unit process "%s"  -  flow #%d: %s', S.Procs{p}, selFlow, S.Inputs(selFlow).Nome);
else, ttl = sprintf('Unit process "%s"', S.Procs{p}); end
dlg = uifigure('Name',ttl,'Color',[1 1 1], ...
               'Position',[round((scr(3)-Wd)/2) round((scr(4)-Hd)/2) Wd Hd]);
setappdata(dlg,'main',fig); setappdata(dlg,'proc',p); setappdata(dlg,'row',0);
uilabel(dlg,'Text','Name:','Position',z*[15 480 45 22],'FontWeight','bold');
D.EFName = uieditfield(dlg,'text','Value',S.Procs{p},'Position',z*[62 480 260 22]);
uibutton(dlg,'Text','RENAME','Position',z*[330 478 90 26],'BackgroundColor',S.cSec, ...
         'FontColor',S.cTxt,'ButtonPushedFcn',@procRename);
D.LblInfo = uilabel(dlg,'Text','','Position',z*[15 448 830 24],'FontColor',[0.3 0.3 0.3]);
D.Tab = uitable(dlg,'Position',z*[15 95 830 348], ...
    'ColumnName',{'#','Flow (dataset process)','Dir','Taxonomy','Qty / law','Unit','Price [EUR/unit]','CF (category)'}, ...
    'ColumnEditable',[false false false false true false true false], ...
    'ColumnWidth',{round(34*z), round(240*z), round(50*z), round(90*z), round(120*z), round(55*z), round(110*z), round(100*z)}, ...
    'CellEditCallback',@procEdit,'CellSelectionCallback',@procSelect);
uilabel(dlg,'Text','Editable: quantity of static / quasi-static flows and unit prices. Dynamic laws and real-time channels are defined in Step 3.', ...
        'Position',z*[15 68 830 22],'FontAngle','italic','FontColor',[0.45 0.45 0.45]);
uibutton(dlg,'Text','REMOVE SELECTED FLOW','Position',z*[15 22 190 30],'BackgroundColor',[0.98 0.90 0.88], ...
         'FontColor',[0.60 0.15 0.10],'FontWeight','bold','ButtonPushedFcn',@procRemove);
uibutton(dlg,'Text','+ ADD FLOW HERE','Position',z*[215 22 150 30],'BackgroundColor',S.cSec, ...
         'FontColor',S.cTxt,'FontWeight','bold','ButtonPushedFcn',@procAddFlow);
uibutton(dlg,'Text','EDIT COSTS','Position',z*[375 22 120 30],'BackgroundColor',S.cSec, ...
         'FontColor',S.cTxt,'FontWeight','bold','ButtonPushedFcn',@procCosts);
uibutton(dlg,'Text','CLOSE','Position',z*[745 22 100 30],'BackgroundColor',S.cPri, ...
         'FontColor',[1 1 1],'FontWeight','bold','ButtonPushedFcn',@(~,~) delete(dlg));
setappdata(dlg,'D',D);
fillProcDialog(dlg);
end


function fillProcDialog(dlg)
fig = getappdata(dlg,'main'); S = getappdata(fig,'S');
p = getappdata(dlg,'proc'); D = getappdata(dlg,'D');
nP = numel(S.Procs);
fl = find([S.Inputs.Proc] == p);
hourly = 0;
[itemN, ~] = rtlca_util('costItemNames');
if isequal(size(S.CostP), [nP numel(itemN)]), hourly = sum(S.CostP(p,:)); end
impTxt = '-';
if isfield(S,'TxtMapImp') && numel(S.TxtMapImp) >= p && isvalid(S.TxtMapImp(p))
    impTxt = strrep(S.TxtMapImp(p).String,'impact: ','');
end
D.LblInfo.Text = sprintf('Position %d of %d in the chain  |  %d flows  |  hourly costs %.2f EUR/h  |  impact so far: %s  |  category: %s', ...
    p, nP, numel(fl), hourly, impTxt, rtlca_util('trunc', S.ColLabels{S.DDImpG.Value},30));
rows = cell(numel(fl), 8);
for k = 1:numel(fl)
    in = S.Inputs(fl(k));
    if strcmp(in.DataType,'dynamic'), q = ['v(t) = ' in.LawTxt];
    elseif strcmp(in.DataType,'real-time')
        if in.RTCol > 0, q = ['channel ' in.RTColName]; else, q = 'channel (not mapped)'; end
    else, q = in.Qty; end
    rows(k,:) = {fl(k), in.Nome, in.Dir, in.DataType, q, in.Unit, in.Price, in.Cf};
end
D.Tab.Data = rows;
setappdata(dlg,'rows',fl); setappdata(dlg,'D',D);
end


function procSelect(src,evt)
if ~isempty(evt.Indices), setappdata(ancestor(src,'figure'),'row',evt.Indices(1)); end
end


function procEdit(src,evt)
dlg = ancestor(src,'figure'); fig = getappdata(dlg,'main'); S = getappdata(fig,'S');
fl = getappdata(dlg,'rows'); r = evt.Indices(1); c = evt.Indices(2);
i = fl(r); v = evt.NewData;
if ~isnumeric(v), v = str2double(v); end
if c == 5                                      % quantity
    if ~any(strcmp(S.Inputs(i).DataType,{'static','quasi-static'})) || ~isfinite(v)
        src.Data{r,c} = evt.PreviousData;
        uialert(dlg,'Only the quantity of static / quasi-static flows can be edited here.','Flow'); return;
    end
    S.Inputs(i).Qty = v;
elseif c == 7                                  % unit price
    if ~isfinite(v) || v < 0, src.Data{r,c} = evt.PreviousData; return; end
    S.Inputs(i).Price = v; S.CostsSet = true;
else
    return;
end
src.Data{r,c} = v;
setappdata(fig,'S',S);
refreshList(fig); rtlca_ui('drawMap', fig, []);
invalidateConfig(fig, sprintf('flow #%d edited', i));
end


function procRemove(src,~)
dlg = ancestor(src,'figure'); fig = getappdata(dlg,'main'); S = getappdata(fig,'S');
fl = getappdata(dlg,'rows'); r = getappdata(dlg,'row');
if r < 1 || r > numel(fl), uialert(dlg,'Select a row of the table first.','Remove'); return; end
i = fl(r);
nm = S.Inputs(i).Nome;
S.Inputs(i) = [];
rt = find(strcmp({S.Inputs.DataType},'real-time'));
S.RtList = rt([S.Inputs(rt).RTCol] > 0);
if isempty(S.Inputs), S.DDImpG.Enable = 'on'; end
setappdata(fig,'S',S);
rtlca_persist('addLog', fig, sprintf('Flow "%s" removed from "%s".', nm, S.Procs{getappdata(dlg,'proc')}));
refreshList(fig); rtlca_ui('drawMap', fig, []);
invalidateConfig(fig, 'flow removed');
setappdata(dlg,'row',0);
fillProcDialog(dlg);
end


function procRename(src,~)
dlg = ancestor(src,'figure'); fig = getappdata(dlg,'main'); S = getappdata(fig,'S');
D = getappdata(dlg,'D'); p = getappdata(dlg,'proc');
nm = strtrim(D.EFName.Value);
if isempty(nm), uialert(dlg,'The name cannot be empty.','Rename'); return; end
old = S.Procs{p}; S.Procs{p} = nm;
S.LblChain.Text = strjoin(S.Procs,'  >  ');
S.DDProcU.Items = S.Procs; S.DDProcU.ItemsData = 1:numel(S.Procs);
setappdata(fig,'S',S);
rtlca_persist('addLog', fig, sprintf('Unit process "%s" renamed "%s".', old, nm));
refreshList(fig); rtlca_ui('drawMap', fig, []);
dlg.Name = sprintf('Unit process "%s"', nm);
fillProcDialog(dlg);
end


function procAddFlow(src,~)
dlg = ancestor(src,'figure'); fig = getappdata(dlg,'main'); S = getappdata(fig,'S');
p = getappdata(dlg,'proc');
if S.MaxStep < 3
    uialert(dlg,'Finish the system definition (Step 2, NEXT) first.','Add flow'); return;
end
if S.ConfigDone, invalidateConfig(fig,'flows reopened'); S = getappdata(fig,'S'); end
setappdata(fig,'S',S);
rtlca_ui('gotoStep', fig,3);
S = getappdata(fig,'S'); S.DDProcU.Value = p;
S.LblStatus.Text = sprintf('Add the flows of "%s" (Step 3).', S.Procs{p});
setappdata(fig,'S',S);
delete(dlg);
end


function procCosts(src,~)
dlg = ancestor(src,'figure'); fig = getappdata(dlg,'main');
delete(dlg);
rtlca_costs('onEnterCosts', fig.Children(1), []);      % opens the cost window (any child gives the figure)
end


function f = ced_factors(S, ip)
% [non-renewable, renewable] CED of a dataset row [MJ per unit]; if the
% sub-columns are missing, the total goes to non-renewable.
f = [0 0];
if S.CedCol == 0, return; end
r = S.ProcRow(ip);
nr = 0; rn = 0;
for c = S.CedNRcols, v = S.DbRaw{r, S.CoefCols(c)}; if rtlca_io('is_num', v), nr = nr + double(v); end, end
for c = S.CedRcols,  v = S.DbRaw{r, S.CoefCols(c)}; if rtlca_io('is_num', v), rn = rn + double(v); end, end
if isempty(S.CedNRcols) && isempty(S.CedRcols)
    v = S.DbRaw{r, S.CoefCols(S.CedCol)}; if rtlca_io('is_num', v), nr = double(v); end
end
f = [nr rn];
end


