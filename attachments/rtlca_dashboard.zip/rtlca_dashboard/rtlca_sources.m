function varargout = rtlca_sources(action, varargin)
% rtlca_sources  -  RT-LCA dashboard module: Modules 2 and 5 - acquisition file, grid mix, energy price, cycle clock, confirmation
% Call as  rtlca_sources('functionName', args...)  : dispatches to the local function.
% Functions: onLoadRT, onLoadMix, onLoadPrice, clockSource, populateClock, onDayChanged, onTimeChanged, updateCfMixLbl, map_mix_cf, map_mix_col, map_mix_ced, mix_at, onConfirm, promptQS
f = str2func(action);
[varargout{1:nargout}] = f(varargin{:});
end


function onLoadRT(src,~)
% Loads the acquisition file and matches every energy column to the energy
% (real-time) input of a unit process: default = same order as the processes
% (column 1 -> first process with an energy input, ...), editable in a dialog.
% Each column can feed only one process (no double counting).
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
rtIdx = find(strcmp({S.Inputs.DataType},'real-time'));
if isempty(rtIdx)
    uialert(fig,'Add the energy (real-time) input of at least one unit process in Step 3.','Real-time');
    return;
end
[~, ord] = sort([S.Inputs(rtIdx).Proc]);  rtIdx = rtIdx(ord);   % process order
fr = rtlca_io('resolve_file', S.EFRt.Value,'REAL-TIME file');
if isempty(fr), return; end
S.EFRt.Value = fr;
d = uiprogressdlg(fig,'Title','Loading','Message','Reading real-time file...','Indeterminate','on');
try
    [S.RTt, S.RTData, S.RTNames, S.RTUnits] = rtlca_io('read_rt', fr);
    S.RTLoaded = true;
catch ME
    if isvalid(d), delete(d); end
    uialert(fig, ME.message, 'Real-time reading error'); setappdata(fig,'S',S); return;
end
if isvalid(d), delete(d); end
nE = numel(S.RTNames);
chain = strjoin(arrayfun(@(p) sprintf('%d=%s',p,S.Procs{p}), 1:numel(S.Procs), ...
                'UniformOutput',false), ',  ');
prompts = cell(1,nE); defs = cell(1,nE);
for c = 1:nE
    prompts{c} = sprintf('Column "%s" [%s]  ->  unit process number (%s):', ...
                         S.RTNames{c}, S.RTUnits{c}, chain);
    if c <= numel(rtIdx), defs{c} = num2str(S.Inputs(rtIdx(c)).Proc); else, defs{c} = '0'; end
end
answ = inputdlg(prompts,'Match energy columns to unit processes (0 = ignore column)',1,defs);
if isempty(answ), setappdata(fig,'S',S); return; end
pAss = zeros(1,nE);
for c = 1:nE
    pAss(c) = str2double(answ{c});
    if ~isfinite(pAss(c)) || pAss(c) < 0 || pAss(c) > numel(S.Procs) || pAss(c) ~= round(pAss(c))
        uialert(fig,sprintf('Invalid process number for column "%s".',S.RTNames{c}),'Real-time');
        setappdata(fig,'S',S); return;
    end
    if pAss(c) > 0
        if sum(pAss(1:c) == pAss(c)) > 1
            uialert(fig,sprintf('Process "%s" receives two columns: one column per process.', ...
                    S.Procs{pAss(c)}),'Real-time'); setappdata(fig,'S',S); return;
        end
        if ~any([S.Inputs(rtIdx).Proc] == pAss(c))
            uialert(fig,sprintf(['Process "%s" has no energy input: add it in Step 3 ' ...
                    'or assign the column to another process.'],S.Procs{pAss(c)}),'Real-time');
            setappdata(fig,'S',S); return;
        end
    end
end
% ---- apply the matching ----
for j = rtIdx, S.Inputs(j).RTCol = 0; end
rtlca_persist('addLog', fig,'Energy columns -> unit processes:');
for c = 1:nE
    if pAss(c) == 0, rtlca_persist('addLog', fig, sprintf('   %-22s ignored', S.RTNames{c})); continue; end
    j = rtIdx([S.Inputs(rtIdx).Proc] == pAss(c));
    fProc = rtlca_util('energy_toMJ', S.Inputs(j).Unit);
    if isnan(fProc)
        uialert(fig,sprintf('"%s" has unit "%s": the energy input must be an MJ process.', ...
                S.Inputs(j).Nome, S.Inputs(j).Unit),'Real-time'); setappdata(fig,'S',S); return;
    end
    S.Inputs(j).RTCol = c;
    S.Inputs(j).RTColName = S.RTNames{c};
    S.Inputs(j).RTConv = rtlca_util('energy_toMJ', S.RTUnits{c}) / fProc;
    S.Inputs(j).Nome = sprintf('%s <- %s', rtlca_util('trunc', S.Procs{pAss(c)},10), S.RTNames{c});
    rtlca_persist('addLog', fig, sprintf('   %-22s -> %-12s [%s -> %s] x%.5g', S.RTNames{c}, ...
           S.Procs{pAss(c)}, S.RTUnits{c}, S.Inputs(j).Unit, S.Inputs(j).RTConv));
end
S.RtList = rtIdx([S.Inputs(rtIdx).RTCol] > 0);
unm = rtIdx([S.Inputs(rtIdx).RTCol] == 0);
for j = unm
    rtlca_persist('addLog', fig, sprintf('   WARNING: energy input of "%s" has no column yet.', S.Procs{S.Inputs(j).Proc}));
end
S.LblRtInfo.Text = sprintf('%d columns matched to %d process energy inputs', ...
                           sum(pAss > 0), numel(rtIdx));
S.LblStatus.Text = sprintf('RT file: %d rows, %d columns matched. Load the grid mix, then CONFIRM.', ...
                           numel(S.RTt), sum(pAss > 0));
setappdata(fig,'S',S);
rtlca_system('refreshList', fig);
rtlca_ui('drawMap', fig, []);
end


function onLoadMix(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if ~S.Loaded
    uialert(fig,'Load the CF database first (Step 1).','Grid mix'); return;
end
ft = rtlca_io('resolve_file', S.EFTerna.Value,'Terna grid-mix file');
if isempty(ft), return; end
S.EFTerna.Value = ft;
d = uiprogressdlg(fig,'Title','Loading','Message','Reading grid mix...','Indeterminate','on');
try
    [S.MixT, S.MixSrc, S.MixGen] = rtlca_io('read_terna', ft);
    S.MixCf = map_mix_cf(S);
    S.MixCed = map_mix_ced(S);
    S.MixLoaded = true;
    setappdata(fig,'S',S);
    populateClock(fig);
    S = getappdata(fig,'S');
    S.LblStatus.Text = sprintf('Grid mix loaded: %d intervals, sources: %s.', ...
                               numel(S.MixT), strjoin(S.MixSrc,', '));
    rtlca_persist('addLog', fig,'Grid mix source -> dataset CF mapping:');
    for q = 1:numel(S.MixSrc)
        rtlca_persist('addLog', fig, sprintf('   %-17s cf = %.6g', S.MixSrc{q}, S.MixCf(q)));
    end
catch ME
    uialert(fig, ME.message, 'Grid mix reading error');
end
if isvalid(d), delete(d); end
setappdata(fig,'S',S);
end


function onLoadPrice(src,~)
% 15-min zonal day-ahead price (energy-charts export): real-time economic datum
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
fp = rtlca_io('resolve_file', S.EFPrice.Value,'energy price file (energy-charts)');
if isempty(fp), return; end
S.EFPrice.Value = fp;
d = uiprogressdlg(fig,'Title','Loading','Message','Reading energy prices...','Indeterminate','on');
try
    [S.PriceT, S.PriceKWh, zone] = rtlca_io('read_prices', fp, 'IT-South');
    S.PriceLoaded = true;
    setappdata(fig,'S',S);
    if ~S.MixLoaded, populateClock(fig); end
    S = getappdata(fig,'S');
    S.LblStatus.Text = sprintf('Energy price loaded: %d intervals (%s), %.3f-%.3f EUR/kWh.', ...
                               numel(S.PriceT), zone, min(S.PriceKWh), max(S.PriceKWh));
    rtlca_persist('addLog', fig, sprintf('Energy price file loaded (zone %s): %s -> %s', zone, ...
           datestr(S.PriceT(1),'dd/mm HH:MM'), datestr(S.PriceT(end),'dd/mm HH:MM')));
catch ME
    uialert(fig, ME.message, 'Price reading error');
end
if isvalid(d), delete(d); end
setappdata(fig,'S',S);
end


function T = clockSource(S)
% timestamps available for the cycle clock: grid mix if loaded, else price file
if S.MixLoaded, T = S.MixT; elseif S.PriceLoaded, T = S.PriceT; else, T = []; end
end


function populateClock(fig)
S = getappdata(fig,'S');
T = clockSource(S);
if isempty(T), return; end
days = unique(floor(T));
S.DDDay.Items = cellstr(datestr(days,'yyyy-mm-dd'));
S.DDDay.ItemsData = days;
dDef = datenum(2026,8,31);
if any(days == dDef), S.DDDay.Value = dDef; else, S.DDDay.Value = days(1); end
setappdata(fig,'S',S);
onDayChanged(S.DDDay,[]);
end


function onDayChanged(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
T = clockSource(S);
if isempty(T), return; end
day = S.DDDay.Value;
tt = T(floor(T) == day);
if isempty(tt), return; end
S.DDTime.Items = cellstr(datestr(tt,'HH:MM'));
S.DDTime.ItemsData = tt;
i15 = find(abs(tt - (day + 15/24)) < 1e-6, 1);
if ~isempty(i15), S.DDTime.Value = tt(i15); else, S.DDTime.Value = tt(1); end
setappdata(fig,'S',S);
updateCfMixLbl(fig);
end


function onTimeChanged(src,~)
updateCfMixLbl(ancestor(src,'figure'));
end


function updateCfMixLbl(fig)
S = getappdata(fig,'S');
if ~isnumeric(S.DDTime.Value), return; end
if S.MixLoaded
    [~, cf] = mix_at(S, S.DDTime.Value);
    S.LblCfMix.Text = sprintf('cf=%.4g', cf);
elseif S.PriceLoaded
    ip = find(S.PriceT <= S.DDTime.Value, 1, 'last'); if isempty(ip), ip = 1; end
    S.LblCfMix.Text = sprintf('%.3f EUR/kWh', S.PriceKWh(ip));
end
setappdata(fig,'S',S);
end


function cfv = map_mix_cf(S)
cfv = map_mix_col(S, S.DDImpG.Value);
end


function cfv = map_mix_col(S, colIdx)
kw = containers.Map( ...
    {'Thermal','Wind','Photovoltaic','Self-consumption','Hydro','Geothermal'}, ...
    {'electricity gas eu','average onshore','pv panel','pv panel','hydropower','__none__'});
fb = 'electricity italy production';
nS = numel(S.MixSrc);
cfv = zeros(1,nS);
for q = 1:nS
    src = S.MixSrc{q};
    if isKey(kw, src), pat = kw(src); else, pat = '__none__'; end
    idx = 0;
    for i = 1:numel(S.ProcNames)
        if strcmpi(strtrim(S.ProcUnits{i}),'MJ') && ...
           ~isempty(strfind(lower(S.ProcNames{i}), pat)) %#ok<STREMP>
            idx = i; break;
        end
    end
    if idx == 0
        for i = 1:numel(S.ProcNames)
            if strcmpi(strtrim(S.ProcUnits{i}),'MJ') && ...
               ~isempty(strfind(lower(S.ProcNames{i}), fb)) %#ok<STREMP>
                idx = i; break;
            end
        end
    end
    if idx == 0, error('No dataset row found for grid source "%s".', src); end
    v = S.DbRaw{ S.ProcRow(idx), S.CoefCols(colIdx) };
    if ~rtlca_io('is_num', v), error('Non-numeric CF for source "%s".', src); end
    cfv(q) = double(v);
end
end


function M = map_mix_ced(S)
% per-source [non-renewable, renewable] CED factors of the grid mix
nS = numel(S.MixSrc);
M = zeros(nS,2);
if S.CedCol == 0, return; end
for c = S.CedNRcols, M(:,1) = M(:,1) + map_mix_col(S, c)'; end
for c = S.CedRcols,  M(:,2) = M(:,2) + map_mix_col(S, c)'; end
end


function [sh, cf] = mix_at(S, dn)
i = find(S.MixT <= dn, 1, 'last');
if isempty(i), i = 1; end
g = S.MixGen(i,:); g(~isfinite(g) | g < 0) = 0;
tot = sum(g);
if tot > 0, sh = g/tot; else, sh = zeros(size(g)); end
cf = sh * S.MixCf(:);
end


function onConfirm(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
rtIdx = find(strcmp({S.Inputs.DataType},'real-time'));
S.RtList = rtIdx([S.Inputs(rtIdx).RTCol] > 0);
if ~isempty(rtIdx)
    if ~S.RTLoaded
        uialert(fig,'There are real-time flows but the file has not been loaded.','Configuration');
        return;
    end
    for j = rtIdx
        if S.Inputs(j).RTCol == 0
            uialert(fig,sprintf('The energy input of "%s" has no column: press LOAD RT FILE.', ...
                    S.Procs{S.Inputs(j).Proc}),'Configuration');
            return;
        end
    end
end
camp = strtrim(S.EFCamp.Value);
if isempty(camp), camp = 'Campaign_1'; S.EFCamp.Value = camp; end
S.Campaign = camp;
setappdata(fig,'S',S);
if ~promptQS(fig), return; end
S = getappdata(fig,'S');
S.ConfigDone = true;
S.ExpN = 1; S.TOffset = 0; S.HotN = 0;
S.Results = struct([]); S.Series = {};      % new campaign: empty results archive
if ~isempty(rtIdx) && isnumeric(S.DDTime.Value) && ~isempty(S.DDTime.ItemsData)
    S.MixStart = S.DDTime.Value;          % cycle clock start (mix and/or price)
end
if ~isempty(rtIdx) && S.PriceLoaded && isfinite(S.MixStart)
    rtlca_persist('addLog', fig, sprintf('Energy price: 15-min market price from %s (replaces the bill price).', ...
                        datestr(S.MixStart,'dd/mm HH:MM')));
elseif ~isempty(rtIdx)
    rtlca_persist('addLog', fig, sprintf('Energy price: fixed bill price %.4f EUR/kWh.', S.EnergyBill));
end
if ~isempty(rtIdx) && S.MixLoaded && isfinite(S.MixStart)
    [sh0, cf0] = mix_at(S, S.MixStart);
    rtlca_persist('addLog', fig, sprintf('Grid mix window start: %s  (cf mix = %.6g)', ...
                        datestr(S.MixStart,'dd/mm HH:MM'), cf0));
    for q = 1:numel(S.MixSrc)
        rtlca_persist('addLog', fig, sprintf('   %-17s %5.1f%%', S.MixSrc{q}, 100*sh0(q)));
    end
elseif ~isempty(rtIdx)
    rtlca_persist('addLog', fig,'Grid mix NOT loaded: real-time flows use their fixed dataset CF.');
end
S.LblExp.Text = sprintf('Cycle %d', S.ExpN);
S.LblStatus.Text = sprintf('Campaign "%s" ready: press START.', S.Campaign);
rtlca_persist('addLog', fig, sprintf('[%s] Campaign started (category: %s).', S.Campaign, ...
                    rtlca_util('trunc', S.ColLabels{S.DDImpG.Value},40)));
setappdata(fig,'S',S);
rtlca_engine('createUnified', fig);
rtlca_engine('resetCycle', fig);
rtlca_ui('gotoStep', fig,6);
end


function ok = promptQS(fig)
ok = true;
S = getappdata(fig,'S');
qs = find(strcmp({S.Inputs.DataType},'quasi-static'));
if isempty(qs), return; end
prompts = cell(1,numel(qs)); defs = cell(1,numel(qs));
for k = 1:numel(qs)
    j = qs(k);
    prompts{k} = sprintf('%s [%s] (%s):', S.Inputs(j).Nome, S.Inputs(j).Unit, ...
                         S.Procs{S.Inputs(j).Proc});
    if isnan(S.Inputs(j).Qty), defs{k} = ''; else, defs{k} = num2str(S.Inputs(j).Qty); end
end
answ = inputdlg(prompts, sprintf('Quasi-static values (cycle %d)', max(S.ExpN,1)), 1, defs);
if isempty(answ), ok = false; return; end
for k = 1:numel(qs)
    v = str2double(answ{k});
    if ~isfinite(v)
        uialert(fig,sprintf('Invalid value for "%s".',S.Inputs(qs(k)).Nome),'Quasi-static');
        ok = false; return;
    end
    S.Inputs(qs(k)).Qty = v;
end
setappdata(fig,'S',S);
rtlca_system('refreshList', fig);
end


