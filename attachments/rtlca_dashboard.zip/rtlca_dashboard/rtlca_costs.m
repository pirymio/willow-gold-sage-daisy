function varargout = rtlca_costs(action, varargin)
% rtlca_costs  -  RT-LCA dashboard module: LCC data: cost window per unit process
% Call as  rtlca_costs('functionName', args...)  : dispatches to the local function.
% Functions: onEnterCosts, fillCostTable, costSel, costEdit, costSave, onCostsNext
f = str2func(action);
[varargout{1:nargout}] = f(varargin{:});
end


function onEnterCosts(src,~)
% Opens the COST WINDOW: processes on the left, editable cost table on the
% right. Structure per unit process:
%   - hourly items (capital + operating), see costItemNames
%   - purchase price of every input flow, disposal/treatment cost of every
%     output flow [EUR per flow unit]
% GLOBAL section: energy price from the bill [EUR/kWh], carbon price
% [EUR/tCO2e] (monetised impact, E-LCC internalisation), disruption cost
% charged during hotspots [EUR/h], product units per cycle (cost per unit).
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
nP = numel(S.Procs);
[itemN, ~] = rtlca_util('costItemNames');
if ~isequal(size(S.CostP), [nP numel(itemN)]), S.CostP = zeros(nP, numel(itemN)); end
setappdata(fig,'S',S);
tmp = struct('CostP',S.CostP, 'Price',[S.Inputs.Price], 'EnergyBill',S.EnergyBill, ...
             'CarbonPrice',S.CarbonPrice, 'DisrCost',S.DisrCost, 'Units',S.UnitsPerCycle);
scr = get(0,'ScreenSize'); z = S.Z;
Wd = round(800*z); Hd = round(560*z);
dlg = uifigure('Name','Costs and prices (LCC)','Color',[1 1 1], ...
               'Position',[round((scr(3)-Wd)/2) round((scr(4)-Hd)/2) Wd Hd]);
setappdata(dlg,'main',fig); setappdata(dlg,'tmp',tmp); setappdata(dlg,'sel',1);
uilabel(dlg,'Text','Select a unit process, then edit the "Value" column. Items follow the Environmental LCC categories (capital, operating, end-of-life).', ...
        'Position',z*[15 520 770 22],'FontAngle','italic');
D.Lst = uilistbox(dlg,'Items',[S.Procs, {'GLOBAL: energy, carbon, hotspots, units'}], ...
                  'ItemsData',1:nP+1,'Value',1,'Position',z*[15 70 230 440], ...
                  'ValueChangedFcn',@costSel);
D.Tab = uitable(dlg,'Position',z*[260 70 525 440], ...
                'ColumnName',{'Cost item','Value','Unit'}, ...
                'ColumnEditable',[false true false], ...
                'ColumnWidth',{round(320*z), round(95*z), round(90*z)}, ...
                'CellEditCallback',@costEdit);
D.LblSum = uilabel(dlg,'Text','','Position',z*[15 42 770 22],'FontWeight','bold');
uibutton(dlg,'Text','SAVE COSTS','Position',z*[555 8 115 28],'FontWeight','bold', ...
         'BackgroundColor',S.cPri,'FontColor',[1 1 1],'ButtonPushedFcn',@costSave);
uibutton(dlg,'Text','CANCEL','Position',z*[680 8 105 28], ...
         'BackgroundColor',S.cSec,'FontColor',S.cTxt,'ButtonPushedFcn',@(~,~) delete(dlg));
setappdata(dlg,'D',D);
fillCostTable(dlg, 1);
end


function fillCostTable(dlg, sel)
fig = getappdata(dlg,'main'); S = getappdata(fig,'S');
tmp = getappdata(dlg,'tmp'); D = getappdata(dlg,'D');
[itemN, itemU] = rtlca_util('costItemNames');
nP = numel(S.Procs);
rows = {}; map = {};
if sel <= nP
    for k = 1:numel(itemN)
        rows(end+1,:) = {itemN{k}, tmp.CostP(sel,k), itemU{k}}; %#ok<AGROW>
        map{end+1} = {'item', sel, k};                           %#ok<AGROW>
    end
    fl = find([S.Inputs.Proc] == sel & ~strcmp({S.Inputs.DataType},'real-time'));
    for i = fl
        in = S.Inputs(i);
        if strcmp(in.Dir,'Output'), lab = ['Disposal / treatment cost: ' rtlca_util('trunc', in.Nome,30)];
        else, lab = ['Purchase price: ' rtlca_util('trunc', in.Nome,30)]; end
        rows(end+1,:) = {lab, tmp.Price(i), ['EUR/' in.Unit]};  %#ok<AGROW>
        map{end+1} = {'price', i, 0};                           %#ok<AGROW>
    end
    if any([S.Inputs.Proc] == sel & strcmp({S.Inputs.DataType},'real-time'))
        rows(end+1,:) = {'Energy: real-time channel, priced with the GLOBAL energy price', NaN, '-'}; %#ok<AGROW>
        map{end+1} = {'none', 0, 0};                            %#ok<AGROW>
    end
    D.LblSum.Text = sprintf('%s: hourly items %.2f EUR/h', S.Procs{sel}, sum(tmp.CostP(sel,:)));
else
    rows = {'Energy price from the bill (used unless a price file is loaded)', tmp.EnergyBill, 'EUR/kWh'; ...
            'Carbon price (monetised impact, ETS-like; 0 = off)', tmp.CarbonPrice, 'EUR/tCO2e'; ...
            'Disruption cost charged during hotspots', tmp.DisrCost, 'EUR/h'; ...
            'Product units per cycle (for cost per unit)', tmp.Units, 'units'};
    map = {{'bill',0,0},{'carbon',0,0},{'disr',0,0},{'units',0,0}};
    D.LblSum.Text = 'Global economic parameters';
end
D.Tab.Data = rows;
setappdata(dlg,'rowmap',map); setappdata(dlg,'sel',sel); setappdata(dlg,'D',D);
end


function costSel(src,~)
dlg = ancestor(src,'figure');
fillCostTable(dlg, src.Value);
end


function costEdit(src,evt)
dlg = ancestor(src,'figure');
tmp = getappdata(dlg,'tmp'); map = getappdata(dlg,'rowmap');
r = evt.Indices(1);
if evt.Indices(2) ~= 2, return; end
v = evt.NewData;
if ~isnumeric(v), v = str2double(v); end
m = map{r};
if strcmp(m{1},'none') || ~isfinite(v) || v < 0
    src.Data{r,2} = evt.PreviousData;            % revert invalid edits
    return;
end
switch m{1}
    case 'item',   tmp.CostP(m{2}, m{3}) = v;
    case 'price',  tmp.Price(m{2}) = v;
    case 'bill',   tmp.EnergyBill = v;
    case 'carbon', tmp.CarbonPrice = v;
    case 'disr',   tmp.DisrCost = v;
    case 'units',  tmp.Units = max(v, 1);
end
src.Data{r,2} = v;
setappdata(dlg,'tmp',tmp);
D = getappdata(dlg,'D'); sel = getappdata(dlg,'sel');
fig = getappdata(dlg,'main'); S = getappdata(fig,'S');
if sel <= numel(S.Procs)
    D.LblSum.Text = sprintf('%s: hourly items %.2f EUR/h', S.Procs{sel}, sum(tmp.CostP(sel,:)));
end
end


function costSave(src,~)
dlg = ancestor(src,'figure');
fig = getappdata(dlg,'main'); S = getappdata(fig,'S');
tmp = getappdata(dlg,'tmp');
S.CostP = tmp.CostP;
for i = 1:numel(S.Inputs), S.Inputs(i).Price = tmp.Price(i); end
S.EnergyBill = tmp.EnergyBill; S.CarbonPrice = tmp.CarbonPrice;
S.DisrCost = tmp.DisrCost; S.UnitsPerCycle = tmp.Units;
S.CostsSet = true;
setappdata(fig,'S',S);
[itemN, ~] = rtlca_util('costItemNames');
rtlca_persist('addLog', fig,'Costs and prices saved (LCC):');
for p = 1:numel(S.Procs)
    rtlca_persist('addLog', fig, sprintf('   %-16s hourly items %8.2f EUR/h  (CAPEX %.2f, labour %.2f, other OPEX %.2f)', ...
           rtlca_util('trunc', S.Procs{p},16), sum(S.CostP(p,:)), sum(S.CostP(p,1:2)), S.CostP(p,3), sum(S.CostP(p,4:end))));
    fl = find([S.Inputs.Proc] == p & ~strcmp({S.Inputs.DataType},'real-time'));
    for i = fl
        rtlca_persist('addLog', fig, sprintf('      %-26s %8.4g EUR/%s', rtlca_util('trunc', S.Inputs(i).Nome,26), S.Inputs(i).Price, S.Inputs(i).Unit));
    end
end
rtlca_persist('addLog', fig, sprintf('   energy %.4f EUR/kWh | carbon %.1f EUR/tCO2e | disruption %.2f EUR/h | %g units/cycle', ...
       S.EnergyBill, S.CarbonPrice, S.DisrCost, S.UnitsPerCycle));
S.LblStatus.Text = sprintf('Costs saved for %d processes (%d hourly items each). Press NEXT.', ...
                           numel(S.Procs), numel(itemN));
setappdata(fig,'S',S);
delete(dlg);
end


function onCostsNext(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
nP = numel(S.Procs);
[itemN, ~] = rtlca_util('costItemNames');
if ~isequal(size(S.CostP), [nP numel(itemN)]), S.CostP = zeros(nP, numel(itemN)); end
if ~S.CostsSet, rtlca_persist('addLog', fig,'LCC: no costs entered, all prices = 0 (impact only).'); end
setappdata(fig,'S',S);
rtlca_ui('gotoStep', fig,5);
S = getappdata(fig,'S');
if isempty(S.RtList)
    S.LblStatus.Text = 'No real-time flow: press CONFIRM directly.';
else
    S.LblStatus.Text = 'Load the RT file, the grid mix and (optional) the price file, then CONFIRM.';
end
setappdata(fig,'S',S);
end


