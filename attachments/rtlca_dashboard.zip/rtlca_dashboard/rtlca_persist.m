function varargout = rtlca_persist(action, varargin)
% rtlca_persist  -  RT-LCA dashboard module: Module 4 - campaign log and results persistence (Excel + MAT)
% Call as  rtlca_persist('functionName', args...)  : dispatches to the local function.
% Functions: addLog, onSaveResults, write_sheet
f = str2func(action);
[varargout{1:nargout}] = f(varargin{:});
end


function addLog(fig, riga)
S = getappdata(fig,'S');
L = S.TxtLog.Value;
L{end+1} = riga;
S.TxtLog.Value = L;
try, scroll(S.TxtLog,'bottom'); catch, end
end


% #########################################################################
%  CHARTS
% #########################################################################


function onSaveResults(src,~)
% MODULE 4 - persistence: writes the declared system, the results of every
% completed cycle, the per-instant series and the log to an Excel workbook,
% and the full analysis state to a MAT-file (reproducibility / transparency).
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if isempty(S.Results)
    uialert(fig,'No completed cycle yet: run at least one cycle before saving.','Save results'); return;
end
[fn, pth] = uiputfile({'*.xlsx','Excel workbook'}, 'Save campaign results', ...
                      sprintf('RTLCA_%s_%s.xlsx', S.Campaign, datestr(now,'yyyymmdd_HHMM')));
if isequal(fn,0), return; end
fx = fullfile(pth, fn);
d = uiprogressdlg(fig,'Title','Saving','Message','Writing results...','Indeterminate','on');
try
    if isfile(fx), delete(fx); end
    % ---- sheet 1: SYSTEM (goal & scope + inventory as declared) ----
    sys = {'Campaign', S.Campaign; 'Impact category', S.ColLabels{S.DDImpG.Value}; ...
           'Unit processes (flow order)', strjoin(S.Procs,' > '); ...
           'Energy price (bill) [EUR/kWh]', S.EnergyBill; 'Carbon price [EUR/tCO2e]', S.CarbonPrice; ...
           'Disruption cost [EUR/h]', S.DisrCost; 'Units per cycle', S.UnitsPerCycle; ...
           'Grid mix file', S.EFTerna.Value; 'RT file', S.EFRt.Value; 'Dataset', S.EFDb.Value; ...
           'Saved on', datestr(now)};
    hdr = {'#','Unit process','Direction','Taxonomy','Dataset process','Unit','Quantity / law / channel', ...
           'Impact factor','Unit price [EUR/unit]','CED non-renew. [MJ/unit]','CED renew. [MJ/unit]'};
    rows = cell(numel(S.Inputs), numel(hdr));
    for i = 1:numel(S.Inputs)
        in = S.Inputs(i);
        if strcmp(in.DataType,'dynamic'), q = ['v(t) = ' in.LawTxt];
        elseif strcmp(in.DataType,'real-time'), q = ['channel ' in.RTColName];
        else, q = in.Qty; end
        rows(i,:) = {i, S.Procs{in.Proc}, in.Dir, in.DataType, in.Nome, in.Unit, q, in.Cf, in.Price, in.CedF(1), in.CedF(2)};
    end
    [itemN, ~] = rtlca_util('costItemNames');
    costHdr = [{'Unit process'}, itemN];
    costRows = cell(numel(S.Procs), numel(costHdr));
    for p = 1:numel(S.Procs)
        costRows(p,:) = [{S.Procs{p}}, num2cell(S.CostP(p,:))];
    end
    write_sheet(fx, 'System', [sys; {'',''}; [hdr; rows]; {''}; [costHdr; costRows]]);
    % ---- sheet 2: RESULTS per cycle ----
    nP = numel(S.Procs);
    rh = [{'Cycle','Timestamp','Mix start','Total impact','Static LCA','Delta %'}, ...
          strcat('Impact: ', S.Procs), {'Cost total [EUR]','Cost energy [EUR]','Cost disruption [EUR]', ...
          'Cost per unit [EUR]','CED total [MJ]','CED renewable [MJ]','Hotspots','Data quality notes'}];
    rr = cell(numel(S.Results), numel(rh));
    for k = 1:numel(S.Results)
        R = S.Results(k);
        rr(k,:) = [{R.Cycle, R.Timestamp, R.MixStart, R.TotalImpact, R.StaticLCA, R.DeltaPerc}, ...
                   num2cell(R.ProcImpact(1:nP)), {R.CostTotal, R.CostEnergy, R.CostDisruption, ...
                   R.CostPerUnit, R.CEDTotal, R.CEDRenewable, R.Hotspots, strjoin(R.DataQualityNotes, ' | ')}];
    end
    write_sheet(fx, 'Results', [rh; rr]);
    % ---- sheet 3: FLOWS per cycle (impact, cost, CED of every flow) ----
    fh = {'Cycle','#','Unit process','Flow','Taxonomy','Impact','Cost [EUR]','CED NR [MJ]','CED R [MJ]'};
    fr = {};
    for k = 1:numel(S.Results)
        R = S.Results(k);
        for i = 1:numel(R.FlowImpact)
            if i > numel(S.Inputs), break; end
            in = S.Inputs(i);
            fr(end+1,:) = {R.Cycle, i, S.Procs{in.Proc}, in.Nome, in.DataType, R.FlowImpact(i), ...
                           R.FlowCost(i), R.FlowCED(i,1), R.FlowCED(i,2)}; %#ok<AGROW>
        end
    end
    write_sheet(fx, 'Flows', [fh; fr]);
    % ---- sheets 4..: per-instant series of every cycle ----
    sh = {'t [s]','cf mix','price [EUR/kWh]','inst impact','cum impact','cum cost [EUR]','cum CED [MJ]'};
    for k = 1:numel(S.Series)
        if isempty(S.Series{k}), continue; end
        M = S.Series{k}; M = M(all(isfinite(M(:,[1 4 5])),2), :);
        write_sheet(fx, sprintf('Series_cycle%d', k), [sh; num2cell(M)]);
    end
    % ---- sheet: LOG ----
    write_sheet(fx, 'Log', S.TxtLog.Value(:));
    % ---- MAT-file: full analysis state (no graphics handles) ----
    A = struct('Campaign',S.Campaign,'Category',S.ColLabels{S.DDImpG.Value},'Procs',{S.Procs}, ...
               'Inputs',S.Inputs,'CostP',S.CostP,'EnergyBill',S.EnergyBill,'CarbonPrice',S.CarbonPrice, ...
               'DisrCost',S.DisrCost,'UnitsPerCycle',S.UnitsPerCycle,'Results',S.Results, ...
               'Series',{S.Series},'MixSrc',{S.MixSrc},'MixCf',S.MixCf,'MixStart',S.MixStart, ...
               'Log',{S.TxtLog.Value},'SavedOn',datestr(now));
    fm = regexprep(fx, '\.xlsx?$', '.mat');
    save(fm, '-struct', 'A');
    addLog(fig, sprintf('Results saved: %s (+ %s)', fn, [regexprep(fn,'\.xlsx?$','') '.mat']));
    S.LblStatus.Text = sprintf('Results saved to %s (Excel) and .mat (state).', fn);
catch ME
    uialert(fig, ME.message, 'Save error');
end
if isvalid(d), delete(d); end
setappdata(fig,'S',S);
end


function write_sheet(file, sheet, C)
% writecell with xlswrite fallback (older releases)
try
    writecell(C, file, 'Sheet', sheet);
catch
    xlswrite(file, C, sheet);
end
end


