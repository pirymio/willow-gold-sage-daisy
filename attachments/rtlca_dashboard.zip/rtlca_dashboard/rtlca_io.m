function varargout = rtlca_io(action, varargin)
% rtlca_io  -  RT-LCA dashboard module: file readers: dataset, acquisition, Terna, prices, and cell helpers
% Call as  rtlca_io('functionName', args...)  : dispatches to the local function.
% Functions: resolve_file, get_sheets, read_sheet, read_db, clean_label, read_rt, read_terna, read_prices, to_dn, tonum, short_src, col_letter, is_num, as_text
f = str2func(action);
[varargout{1:nargout}] = f(varargin{:});
end


function f = resolve_file(name, descr)
f = '';
if exist(name,'file') == 2, f = name; return; end
[fn, pth] = uigetfile({'*.xlsx;*.xls','Excel files'}, ['Select the ' descr]);
if isequal(fn,0), return; end
f = fullfile(pth, fn);
end


function s = get_sheets(file)
try
    s = cellstr(sheetnames(file));
catch
    [~, s] = xlsfinfo(file); s = cellstr(s);
end
end


function raw = read_sheet(file, sheet)
try
    raw = readcell(file, 'Sheet', sheet);
catch
    [~,~,raw] = xlsread(file, sheet);
end
end


function [raw, coefCols, colLabels, procNames, procUnits, procRow] = read_db(file)
sheets = get_sheets(file);
raw    = read_sheet(file, sheets{1});
[nR, nC] = size(raw);
if nR < 4, error('Unexpected coefficient-database format.'); end
dataRows = 4:nR; colUnit = 5; colName = 6;
coefCols = [];
sample = dataRows(1:min(numel(dataRows),400));
for c = 7:nC
    cnt = 0;
    for r = sample
        if is_num(raw{r,c}), cnt = cnt + 1; end
    end
    if cnt > 0.5*numel(sample), coefCols(end+1) = c; end %#ok<AGROW>
end
if isempty(coefCols), error('No indicator column found.'); end
colLabels = cell(1,numel(coefCols));
for i = 1:numel(coefCols)
    colLabels{i} = clean_label(raw{1,coefCols(i)}, raw{2,coefCols(i)}, raw{3,coefCols(i)});
end
procNames = {}; procUnits = {}; procRow = [];
for r = dataRows
    nm = as_text(raw{r,colName});
    if isempty(nm), continue; end
    anyNum = false;
    for i = 1:numel(coefCols)
        if is_num(raw{r,coefCols(i)}), anyNum = true; break; end
    end
    if ~anyNum, continue; end
    procNames{end+1} = nm;                      %#ok<AGROW>
    procUnits{end+1} = as_text(raw{r,colUnit}); %#ok<AGROW>
    procRow(end+1)   = r;                       %#ok<AGROW>
end
if isempty(procNames), error('No valid process found in the database.'); end
end


function lbl = clean_label(a, b, c)
parts = {}; vals = {a,b,c};
for i = 1:3
    s = as_text(vals{i});
    if ~isempty(s) && s(1) ~= '.', parts{end+1} = s; end %#ok<AGROW>
end
if isempty(parts), lbl = '(unnamed)'; else, lbl = strjoin(parts,' - '); end
end


function [t, data, names, units] = read_rt(file)
sheets = get_sheets(file);
sheet  = sheets{end};
for i = 1:numel(sheets)
    if strcmpi(sheets{i},'Data1'), sheet = sheets{i}; break; end
end
raw = read_sheet(file, sheet);
[nR, nC] = size(raw);
unitsRow = 0;
for r = 1:min(nR,8)
    for c = 1:nC
        u = as_text(raw{r,c});
        if strcmpi(u,'s') || ~isnan(rtlca_util('energy_toMJ', u)), unitsRow = r; break; end
    end
    if unitsRow > 0, break; end
end
if unitsRow == 0
    error('Units row not found (energy units expected in row 2).');
end
nameRow = max(unitsRow-1,1);
timeCol = 0; eCols = []; eUnits = {}; eNames = {};
for c = 1:nC
    u = as_text(raw{unitsRow,c});
    if strcmpi(u,'s') && timeCol == 0, timeCol = c; end
    if ~isnan(rtlca_util('energy_toMJ', u))
        eCols(end+1) = c; eUnits{end+1} = u;    %#ok<AGROW>
        nm = as_text(raw{nameRow,c});
        if isempty(nm), nm = sprintf('Energy %s', col_letter(c)); end
        eNames{end+1} = sprintf('%s (%s)', nm, col_letter(c)); %#ok<AGROW>
    end
end
if isempty(eCols)
    error('No column with an energy unit (Wh, kWh, J, kJ, MJ, GJ, MWh).');
end
nE = numel(eCols);
t = zeros(nR,1); data = zeros(nR,nE); m = 0;
for r = unitsRow+1:nR
    if timeCol > 0
        tvv = raw{r,timeCol};
        if ~is_num(tvv), break; end
    else
        tvv = m + 1;
    end
    row = zeros(1,nE); ok = true;
    for i = 1:nE
        x = raw{r,eCols(i)};
        if is_num(x), row(i) = x; else, ok = false; break; end
    end
    if ~ok, break; end
    m = m + 1; t(m) = tvv; data(m,:) = row;
end
t = t(1:m); data = data(1:m,:);
if m == 0, error('No valid numeric data row in the real-time file.'); end
names = eNames; units = eUnits;
end


function [T, srcNames, Gen] = read_terna(file)
sheets = get_sheets(file);
raw = read_sheet(file, sheets{1});
nR = size(raw,1);
dn = []; vv = []; si = []; srcNames = {};
for r = 2:nR
    d = to_dn(raw{r,1});
    v = tonum(raw{r,2});
    src = as_text(raw{r,3});
    if isnan(d) || isnan(v) || isempty(src), continue; end
    q = find(strcmp(srcNames, src), 1);
    if isempty(q), srcNames{end+1} = src; q = numel(srcNames); end %#ok<AGROW>
    dn(end+1) = d; vv(end+1) = v; si(end+1) = q; %#ok<AGROW>
end
if isempty(dn), error('No valid rows in the Terna file.'); end
T = unique(dn(:));
nS = numel(srcNames);
Gen = zeros(numel(T), nS);
[~, ti] = ismember(dn(:), T);
for k = 1:numel(dn)
    Gen(ti(k), si(k)) = vv(k);
end
end


function [T, kwh, zone] = read_prices(file, zone)
% energy-charts export: row 2 headers, row 3 units, data from row 4:
% col 1 date (CEST), price columns "... (IT-zone)" in EUR/MWh.
sheets = get_sheets(file);
raw = read_sheet(file, sheets{1});
hdr = raw(2,:);
col = 0;
for c = 1:numel(hdr)
    h = as_text(hdr{c});
    if ~isempty(strfind(lower(h),'prezzo')) && ~isempty(strfind(h,zone)), col = c; break; end %#ok<STREMP>
end
if col == 0
    for c = 1:numel(hdr)                       % fallback: first price column
        if ~isempty(strfind(lower(as_text(hdr{c})),'prezzo')), col = c; zone = as_text(hdr{c}); break; end %#ok<STREMP>
    end
end
if col == 0, error('No price column found in the file.'); end
n = size(raw,1);
T = nan(n,1); kwh = nan(n,1);
for r = 4:n
    dn = to_dn(raw{r,1}); v = tonum(raw{r,col});
    if ~isnan(dn) && isfinite(v), T(r) = dn; kwh(r) = v/1000; end
end
keep = isfinite(T) & isfinite(kwh);
T = T(keep); kwh = kwh(keep);
if isempty(T), error('No valid price rows in the file.'); end
end


% #########################################################################
%  STEP 5: RT SOURCE (auto-map + assignment to unit processes) & GRID MIX
% #########################################################################


function d = to_dn(x)
d = NaN;
if isa(x,'datetime')
    d = datenum(x);
elseif ischar(x) || (isstring(x) && isscalar(x))
    t = strtrim(char(x));
    try, d = datenum(t,'yyyy-mm-dd HH:MM:SS'); catch
        try, d = datenum(t); catch, d = NaN; end
    end
elseif isnumeric(x) && isscalar(x) && isfinite(x)
    if x > 200000, d = x;
    elseif x > 20000, d = x + 693960;
    end
end
end


function v = tonum(x)
if isnumeric(x) && isscalar(x), v = double(x);
elseif ischar(x) || (isstring(x) && isscalar(x)), v = str2double(x);
else, v = NaN;
end
end


function nm = short_src(s)
i = find(s == '-' | s == ' ', 1);
if isempty(i), nm = s; else, nm = s(1:i-1); end
nm = rtlca_util('trunc', nm, 7);
end


function L = col_letter(c)
L = '';
while c > 0
    r = mod(c-1,26);
    L = [char(65+r) L]; %#ok<AGROW>
    c = floor((c-1)/26);
end
end


function ok = is_num(x)
ok = isnumeric(x) && isscalar(x) && ~isnan(x) && isfinite(x);
end


function s = as_text(x)
if ischar(x), s = strtrim(x);
elseif isstring(x) && isscalar(x), s = strtrim(char(x));
else, s = '';
end
end


