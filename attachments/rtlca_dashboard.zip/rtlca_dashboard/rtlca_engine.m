function varargout = rtlca_engine(action, varargin)
% rtlca_engine  -  RT-LCA dashboard module: Modules 5-6-7 - cycle preparation and streaming engine (LCI, LCIA, LCC, CED, interpretation)
% Call as  rtlca_engine('functionName', args...)  : dispatches to the local function.
% Functions: createUnified, markCycle, resetCycle, onStop, onStartExp, onNewExp, onClose, gauge_create, gauge_update
f = str2func(action);
[varargout{1:nargout}] = f(varargin{:});
end


function createUnified(fig)
S = getappdata(fig,'S');
nIn = numel(S.Inputs);
cmap = lines(max(nIn,7));
S.CmapIn = cmap;
cla(S.AxVal); hold(S.AxVal,'on'); grid(S.AxVal,'on');
S.LnVal = gobjects(1,nIn);
for i = 1:nIn
    switch S.Inputs(i).DataType
        case 'static',       ls = '-';  lw = 2.2; mk = 'none';
        case 'quasi-static', ls = '--'; lw = 2.0; mk = 'none';
        case 'dynamic',      ls = '-.'; lw = 1.6; mk = 'none';
        otherwise,           ls = '-';  lw = 1.2; mk = '.';
    end
    nm = sprintf('#%d %s (%s)', i, rtlca_util('trunc', S.Inputs(i).Nome,18), S.Inputs(i).DataType);
    S.LnVal(i) = animatedline(S.AxVal,'Color',cmap(i,:),'LineStyle',ls,'LineWidth',lw, ...
                              'Marker',mk,'MarkerSize',7,'DisplayName',nm);
end
try, legend(S.AxVal,'show','Location','best','Interpreter','none','FontSize',7); catch, end
setappdata(fig,'S',S);
end


function markCycle(fig)
S = getappdata(fig,'S');
try, xline(S.AxVal, S.TOffset, ':', sprintf('Cycle %d', S.ExpN)); catch, end
end


function resetCycle(fig)
S = getappdata(fig,'S');
if ~S.ConfigDone, return; end
nIn = numel(S.Inputs);
nP  = numel(S.Procs);
cmap = S.CmapIn;
if ~isempty(S.RtList), S.Tvec = S.RTt;
else, S.Tvec = (0:0.5:120)'; end
S.NSteps = numel(S.Tvec);
S.Idx = 1;
S.AxVal.XLim = [0 S.TOffset + (S.Tvec(end)-S.Tvec(1)) + 1];
markCycle(fig);

% ---- instantaneous impact profile ----
cla(S.AxImp); hold(S.AxImp,'on'); grid(S.AxImp,'on');
S.LnImpTot = animatedline(S.AxImp,'Color',[0 0 0],'LineWidth',2.2,'DisplayName','TOTAL');
S.LnHot    = animatedline(S.AxImp,'Color',[0.85 0.1 0.1],'LineStyle','none', ...
                          'Marker','o','MarkerSize',6,'DisplayName','hotspot');
if S.EFSoglia.Value > 0
    try, yline(S.AxImp, S.EFSoglia.Value, '--', 'threshold'); catch, end
end
try, legend(S.AxImp,'show','Location','northwest','FontSize',7); catch, end

% ---- cumulative impact profile ----
cla(S.AxCum); hold(S.AxCum,'on'); grid(S.AxCum,'on');
S.LnCum = animatedline(S.AxCum,'Color',[0 0.35 0.65],'LineWidth',2.2,'DisplayName','RT-LCA');
if S.EFStat.Value > 0
    try, yline(S.AxCum, S.EFStat.Value, '-', 'static LCA'); catch, end
end
try, legend(S.AxCum,'show','Location','northwest','FontSize',7); catch, end

% ---- PARETO: stacked histogram, one column per unit process ----
cla(S.AxPar); hold(S.AxPar,'on'); grid(S.AxPar,'on');
S.ParPatch = gobjects(1,nIn);
for i = 1:nIn
    p = S.Inputs(i).Proc;
    S.ParPatch(i) = patch(S.AxPar, 'XData',[p-0.32 p+0.32 p+0.32 p-0.32], ...
        'YData',[0 0 0 0], 'FaceColor',cmap(i,:), 'EdgeColor','k', ...
        'DisplayName',sprintf('#%d %s', i, rtlca_util('trunc', S.Inputs(i).Nome,18)));
end
S.ParSegTxt = gobjects(1,nIn);
for i = 1:nIn
    S.ParSegTxt(i) = text(S.AxPar, S.Inputs(i).Proc, 0, '', 'HorizontalAlignment','center', ...
        'VerticalAlignment','middle','FontSize',8,'Interpreter','none');
end
S.ParTopTxt = gobjects(1,nP);
for p = 1:nP
    S.ParTopTxt(p) = text(S.AxPar, p, 0, '', 'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom','FontWeight','bold','FontSize',10);
end
S.AlarmDone = false(1,nP);
S.LblAlarm.Text = '';
S.LblDQ.Text = '';
% real-time coverage of every column (blue text above the total)
S.ParRtTxt = gobjects(1,nP);
for p = 1:nP
    S.ParRtTxt(p) = text(S.AxPar, p, 0, '', 'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom','FontSize',9,'Color',[0.13 0.45 0.71]);
end

% ---- LCC: cost per unit process (flows + CAPEX + labour) and cumulative ----
cla(S.AxCostPar); hold(S.AxCostPar,'on'); grid(S.AxCostPar,'on');
S.CostPatch = gobjects(1,nIn);
for i = 1:nIn
    p = S.Inputs(i).Proc;
    S.CostPatch(i) = patch(S.AxCostPar, 'XData',[p-0.32 p+0.32 p+0.32 p-0.32], ...
        'YData',[0 0 0 0], 'FaceColor',cmap(i,:), 'EdgeColor','k', ...
        'DisplayName',sprintf('#%d %s', i, rtlca_util('trunc', S.Inputs(i).Nome,18)));
end
S.CostCapexP = gobjects(1,nP); S.CostLabP = gobjects(1,nP); S.CostOpxP = gobjects(1,nP);
S.CostCarbP = gobjects(1,nP); S.CostTopTxt = gobjects(1,nP);
xq = [-0.32 0.32 0.32 -0.32];
for p = 1:nP
    S.CostCapexP(p) = patch(S.AxCostPar,'XData',p+xq,'YData',[0 0 0 0],'FaceColor',[0.45 0.45 0.45], ...
        'EdgeColor','k','DisplayName','capital (depreciation, tooling)');
    S.CostLabP(p)   = patch(S.AxCostPar,'XData',p+xq,'YData',[0 0 0 0],'FaceColor',[0.72 0.72 0.72], ...
        'EdgeColor','k','DisplayName','labour');
    S.CostOpxP(p)   = patch(S.AxCostPar,'XData',p+xq,'YData',[0 0 0 0],'FaceColor',[0.90 0.90 0.90], ...
        'EdgeColor','k','DisplayName','other OPEX (maintenance, utilities, consumables, overhead)');
    S.CostCarbP(p)  = patch(S.AxCostPar,'XData',p+xq,'YData',[0 0 0 0],'FaceColor',[0.60 0.80 0.60], ...
        'EdgeColor','k','DisplayName','carbon cost (monetised impact)');
    S.CostTopTxt(p) = text(S.AxCostPar, p, 0, '', 'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom','FontWeight','bold','FontSize',10);
end
S.AxCostPar.XLim = [0.3 nP+0.7]; S.AxCostPar.XTick = 1:nP;
S.AxCostPar.XTickLabel = S.Procs; S.AxCostPar.TickLabelInterpreter = 'none';
ylabel(S.AxCostPar,'cost [EUR]');
try
    hl = [S.CostPatch S.CostCapexP(1) S.CostLabP(1) S.CostOpxP(1) S.CostCarbP(1)];
    legend(S.AxCostPar, hl, 'Location','northeastoutside','Interpreter','none','FontSize',8);
catch
end
cla(S.AxCostCum); hold(S.AxCostCum,'on'); grid(S.AxCostCum,'on');
S.LnCost  = animatedline(S.AxCostCum,'Color',[0.10 0.45 0.20],'LineWidth',2.2,'DisplayName','total cost');
S.LnCostE = animatedline(S.AxCostCum,'Color',[0.90 0.50 0.10],'LineWidth',1.4,'DisplayName','energy cost');
ylabel(S.AxCostCum,'EUR');
try, legend(S.AxCostCum,'show','Location','northwest','FontSize',8); catch, end
% energy price along the timeline: file (real-time economic) or bill (static)
S.UsePrice = ~isempty(S.RtList) && S.PriceLoaded && isfinite(S.MixStart);
S.PriceVec = S.EnergyBill * ones(S.NSteps,1);
if S.UsePrice
    for kk = 1:S.NSteps
        dn = S.MixStart + (S.Tvec(kk)-S.Tvec(1))/86400;
        ip = find(S.PriceT <= dn, 1, 'last');
        if ~isempty(ip), S.PriceVec(kk) = S.PriceKWh(ip); end
    end
end
S.CostCumRT = zeros(1,max(numel(S.RtList),1));
S.CostDisr = 0;                          % disruption cost accrued during hotspots

% ---- CED: per unit process (non-renewable / renewable) + cumulative ----
cla(S.AxCed); hold(S.AxCed,'on'); grid(S.AxCed,'on');
S.CedNRP = gobjects(1,nP); S.CedRP = gobjects(1,nP); S.CedTopTxt = gobjects(1,nP);
xq = [-0.32 0.32 0.32 -0.32];
for p = 1:nP
    S.CedNRP(p) = patch(S.AxCed,'XData',p+xq,'YData',[0 0 0 0],'FaceColor',[0.45 0.35 0.25], ...
        'EdgeColor','k','DisplayName','non-renewable (fossil, nuclear, NR biomass)');
    S.CedRP(p)  = patch(S.AxCed,'XData',p+xq,'YData',[0 0 0 0],'FaceColor',[0.45 0.75 0.40], ...
        'EdgeColor','k','DisplayName','renewable (biomass, wind/solar/geo, water)');
    S.CedTopTxt(p) = text(S.AxCed, p, 0, '', 'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom','FontWeight','bold','FontSize',10);
end
S.AxCed.XLim = [0.3 nP+0.7]; S.AxCed.XTick = 1:nP;
S.AxCed.XTickLabel = S.Procs; S.AxCed.TickLabelInterpreter = 'none';
ylabel(S.AxCed,'CED [MJ]');
try, legend(S.AxCed,[S.CedNRP(1) S.CedRP(1)],'Location','northeastoutside','FontSize',8); catch, end
cla(S.AxCedCum); hold(S.AxCedCum,'on'); grid(S.AxCedCum,'on');
S.LnCed   = animatedline(S.AxCedCum,'Color',[0.45 0.30 0.10],'LineWidth',2.2,'DisplayName','CED total');
S.LnCedR  = animatedline(S.AxCedCum,'Color',[0.45 0.75 0.40],'LineWidth',1.4,'DisplayName','renewable part');
ylabel(S.AxCedCum,'MJ');
try, legend(S.AxCedCum,'show','Location','northwest','FontSize',8); catch, end
S.LblCED.Text = 'CED: -';
S.CedMixVec = zeros(S.NSteps,2);         % filled below, once the mix shares exist
S.CedCumRT = zeros(max(numel(S.RtList),1), 2);
S.Rec = nan(S.NSteps, 7);   % [t, cf_mix, price, inst impact, cum impact, cum cost, cum CED]
S.AxPar.XLim = [0.3 nP+0.7]; S.AxPar.XTick = 1:nP;
S.AxPar.XTickLabel = S.Procs; S.AxPar.TickLabelInterpreter = 'none';
S.AxPar.XTickLabelRotation = 15;
ylabel(S.AxPar, rtlca_util('trunc', S.ColLabels{S.DDImpG.Value},60), 'Interpreter','none');
try, legend(S.AxPar,'show','Location','northeastoutside','Interpreter','none','FontSize',8); catch, end

% ---- grid-mix CF along the timeline + mix bars ----
useMix = ~isempty(S.RtList) && S.MixLoaded && isfinite(S.MixStart);
S.UseMix = useMix;
if useMix
    nT = S.NSteps;
    S.CfMixVec = zeros(nT,1);
    S.ShareVec = zeros(nT, numel(S.MixSrc));
    for kk = 1:nT
        dn = S.MixStart + (S.Tvec(kk)-S.Tvec(1))/86400;
        [sh, cf] = rtlca_sources('mix_at', S, dn);
        S.ShareVec(kk,:) = sh;
        S.CfMixVec(kk) = cf;
    end
    if ~isempty(S.MixCed), S.CedMixVec = S.ShareVec * S.MixCed; end   % [NSteps x 2]
end
cla(S.AxMix); hold(S.AxMix,'on'); grid(S.AxMix,'on');
if useMix
    nS_ = numel(S.MixSrc);
    cms = lines(max(nS_,7));
    S.BarMix = gobjects(1,nS_);
    for q = 1:nS_
        S.BarMix(q) = bar(S.AxMix, q, 100*S.ShareVec(1,q), 0.6, ...
                          'FaceColor', cms(q,:), 'EdgeColor','k');
    end
    lbl = cell(1,nS_);
    for q = 1:nS_, lbl{q} = rtlca_io('short_src', S.MixSrc{q}); end
    S.AxMix.XLim = [0.4 nS_+0.6]; S.AxMix.XTick = 1:nS_; S.AxMix.XTickLabel = lbl;
    S.AxMix.TickLabelInterpreter = 'none'; S.AxMix.XTickLabelRotation = 25;
    S.AxMix.YLim = [0 60]; S.AxMix.YTick = 0:20:60;
    title(S.AxMix, sprintf('Italian grid mix @ %s   cf=%.4g', ...
          datestr(S.MixStart,'dd/mm HH:MM'), S.CfMixVec(1)));
else
    title(S.AxMix,'Italian grid mix (not loaded)');
end

% ---- energy sample-and-hold + gauges ----
nRt = numel(S.RtList);
cla(S.AxEins); hold(S.AxEins,'on'); grid(S.AxEins,'on');
if nRt > 0
    cmr = lines(max(nRt,7));
    S.LnEins = gobjects(1,nRt);
    rtNames = cell(1,nRt);
    for k = 1:nRt
        j = S.RtList(k);
        rtNames{k} = sprintf('%s [%s]', rtlca_util('trunc', S.Inputs(j).Nome,12), ...
                             rtlca_util('trunc', S.Procs{S.Inputs(j).Proc},8));
        S.LnEins(k) = animatedline(S.AxEins,'Color',cmr(k,:),'LineWidth',1.2, ...
                                   'Marker','.','MarkerSize',7,'DisplayName',rtNames{k});
    end
    try, legend(S.AxEins,'show','Location','northwest','Interpreter','none','FontSize',7); catch, end
    maxCum = 0; maxEv = 0;
    for k = 1:nRt
        j = S.RtList(k);
        if useMix, cfg = mean(S.CfMixVec); else, cfg = S.Inputs(j).Cf; end
        v = S.RTData(:, S.Inputs(j).RTCol) * S.Inputs(j).RTConv * cfg;
        maxCum = max(maxCum, max(abs(v)));
        dv = diff(v); dv = dv(dv ~= 0);
        if ~isempty(dv), maxEv = max(maxEv, max(abs(dv))); end
    end
    if ~(maxCum > 0), maxCum = 1; end
    if ~(maxEv  > 0), maxEv  = 1; end
    S.G1 = gauge_create(S.AxG1, [0 maxCum],    'RT cumulative impact',    cmr, rtNames);
    S.G2 = gauge_create(S.AxG2, [0 1.2*maxEv], 'RT instantaneous impact', cmr, rtNames);
end
S.LblG1.Text = '-';
S.LblG2.Text = '-';
S.PrevCum = nan(1,max(nRt,1));
S.HeldE   = nan(1,max(nRt,1));
S.HeldI   = nan(1,max(nRt,1));
S.HasEv   = false(1,max(nRt,1));
S.ImpCumRT = zeros(1,max(nRt,1));
S.CumTot  = 0;
setappdata(fig,'S',S);
rtlca_ui('drawMap', fig, []);
end


% #########################################################################
%  CYCLE EXECUTION
% #########################################################################


function onStop(src,~)
setappdata(ancestor(src,'figure'),'RUN',false);
end


function onStartExp(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if ~S.ConfigDone
    uialert(fig,'Complete steps 1-5 first.','Run'); return;
end
if S.Idx > S.NSteps
    uialert(fig,'Cycle already completed: press NEW CYCLE.','Run'); return;
end
S.BtnStart.Enable='off'; S.BtnStop.Enable='on'; S.BtnNew.Enable='off';
setappdata(fig,'S',S);
setappdata(fig,'RUN',true);

nIn = numel(S.Inputs);
nP  = numel(S.Procs);
tv = S.Tvec;
batch = 25;
k = S.Idx;
Inp = S.Inputs; RtList = S.RtList; nRt = numel(RtList);
LnVal = S.LnVal;
prevCum=S.PrevCum; heldE=S.HeldE; heldI=S.HeldI; hasEv=S.HasEv;
impCumRT = S.ImpCumRT;
costCumRT = S.CostCumRT;
cedCumRT = S.CedCumRT; cedMixVec = S.CedMixVec;
ced = zeros(nIn,2);
rec = S.Rec;
priceVec = S.PriceVec;
kwhPerUnit = zeros(1,nIn);                 % flow unit -> kWh (energy flows only)
for i = 1:nIn
    f_ = rtlca_util('energy_toMJ', Inp(i).Unit);
    if ~isnan(f_), kwhPerUnit(i) = f_/3.6; end
end
[itemN_, ~] = rtlca_util('costItemNames');
CostP = S.CostP;
if ~isequal(size(CostP), [nP numel(itemN_)]), CostP = zeros(nP, numel(itemN_)); end
capexP = sum(CostP(:,1:2),2)';            % capital items [EUR/h]
labP   = CostP(:,3)';                     % labour [EUR/h]
opxP   = sum(CostP(:,4:end),2)';          % other operating items [EUR/h]
carbonP = S.CarbonPrice/1000;             % EUR per kg of impact (carbon price EUR/t)
disrRate = S.DisrCost;                    % EUR/h charged while a hotspot is active
costDisr = S.CostDisr;
dtStep = median(diff(tv)); if ~isfinite(dtStep) || dtStep <= 0, dtStep = 1; end
costs = zeros(1,nIn); costTot = 0;
toff = S.TOffset;
useMix = isfield(S,'UseMix') && S.UseMix;
cfMixVec = S.CfMixVec;
useCedMix = useMix && ~isempty(S.MixCed) && any(S.MixCed(:) ~= 0);
soglia = S.EFSoglia.Value;
statVal = S.EFStat.Value;
hotN = S.HotN;
vals = zeros(1,nIn); imps = zeros(1,nIn); impsInst = zeros(1,nIn);
cumTot = S.CumTot;

while k <= S.NSteps
    kEnd = min(k+batch-1, S.NSteps);
    for kk = k:kEnd
        tk = tv(kk);
        tg = toff + (tk - tv(1));
        for i = 1:nIn
            switch Inp(i).DataType
                case {'static','quasi-static'}
                    v = Inp(i).Qty;  vi = v;
                    imps(i) = v * Inp(i).Cf;
                case 'dynamic'
                    v = Inp(i).LawFun(tk);  vi = v;
                    imps(i) = v * Inp(i).Cf;
                otherwise
                    v = S.RTData(kk, Inp(i).RTCol) * Inp(i).RTConv;
                    vi = NaN;   % imps set below from the integral
            end
            vals(i) = v;
            if ~isnan(vi), impsInst(i) = vi * Inp(i).Cf; end
            addpoints(LnVal(i), tg, v);
        end
        for kx = 1:nRt
            j = RtList(kx);
            cum = vals(j);
            if ~isnan(prevCum(kx))
                delta = cum - prevCum(kx);
                if delta ~= 0
                    if hasEv(kx)
                        addpoints(S.LnEins(kx), tk, heldE(kx));
                    end
                    addpoints(S.LnEins(kx), tk, delta);
                    heldE(kx) = delta;
                    if useMix, cfj = cfMixVec(kk); else, cfj = Inp(j).Cf; end
                    heldI(kx) = delta * cfj;
                    impCumRT(kx) = impCumRT(kx) + delta * cfj;
                    costCumRT(kx) = costCumRT(kx) + delta * kwhPerUnit(j) * priceVec(kk);
                    if useCedMix, cedCumRT(kx,:) = cedCumRT(kx,:) + delta * cedMixVec(kk,:);
                    else, cedCumRT(kx,:) = cedCumRT(kx,:) + delta * Inp(j).CedF; end
                    hasEv(kx) = true;
                    impsInst(j) = heldI(kx);
                end
            end
            prevCum(kx) = cum;
            imps(j) = impCumRT(kx);
            costs(j) = costCumRT(kx);
            ced(j,:) = cedCumRT(kx,:);
        end
        for i = 1:nIn
            if ~strcmp(Inp(i).DataType,'real-time'), ced(i,:) = vals(i) * Inp(i).CedF; end
        end
        addpoints(S.LnCed,  tk, sum(ced(:)));
        addpoints(S.LnCedR, tk, sum(ced(:,2)));
        if useMix, cfNow = cfMixVec(kk); else, cfNow = NaN; end
        rec(kk,:) = [tk, cfNow, priceVec(kk), sum(impsInst), sum(imps), NaN, sum(ced(:))];
        % ---- LCC: Cost(t) = sum g(t) * UnitCost(t)  (non-RT flows priced like impacts) ----
        for i = 1:nIn
            if ~strcmp(Inp(i).DataType,'real-time'), costs(i) = vals(i) * Inp(i).Price; end
        end
        elapsedH = (tk - tv(1))/3600;
        costTime = (capexP + labP + opxP) * elapsedH;    % hourly items per unit process
        costCarb = carbonP * abs(imps);                  % monetised impact per flow
        costTot = sum(costs) + sum(costTime) + sum(costCarb) + costDisr;
        rec(kk,6) = costTot;
        addpoints(S.LnCost,  tk, costTot);
        addpoints(S.LnCostE, tk, sum(costCumRT));
        instTot = sum(impsInst);
        addpoints(S.LnImpTot, tk, instTot);
        cumTot = sum(imps);
        addpoints(S.LnCum, tk, cumTot);
        if soglia > 0 && instTot > soglia
            addpoints(S.LnHot, tk, instTot);
            hotN = hotN + 1;
            costDisr = costDisr + disrRate * dtStep/3600;   % disruption cost during hotspots
            if mod(hotN,10) == 1
                rtlca_persist('addLog', fig, sprintf('  HOTSPOT cycle %d: t=%.2f s, inst=%.5g > thr %.5g', ...
                                    S.ExpN, tk, instTot, soglia));
            end
        end
    end
    k = kEnd + 1;

    % ---- per-process aggregation: map texts + stacked Pareto ----
    procImp = zeros(1,nP);
    for i = 1:nIn
        procImp(Inp(i).Proc) = procImp(Inp(i).Proc) + imps(i);
    end
    off = zeros(1,nP);
    segH = abs(imps);
    for i = 1:nIn
        p = Inp(i).Proc;
        set(S.ParPatch(i), 'YData', [off(p) off(p) off(p)+segH(i) off(p)+segH(i)]);
        off(p) = off(p) + segH(i);
    end
    yMax = max(off);
    if yMax > 0, S.AxPar.YLim = [0 1.15*yMax]; end
    % labels inside the slices: flow name + % of its column
    for i = 1:nIn
        p = Inp(i).Proc;
        y0 = get(S.ParPatch(i),'YData');
        if off(p) > 0 && segH(i) >= 0.06*max(yMax,eps)
            set(S.ParSegTxt(i), 'Position', [p (y0(1)+y0(3))/2 0], ...
                'String', sprintf('%s %.0f%%', rtlca_util('trunc', Inp(i).Nome,14), 100*segH(i)/off(p)));
        else
            set(S.ParSegTxt(i), 'String', '');
        end
    end
    totAll = sum(off);
    dqList = {};
    for p = 1:nP
        set(S.ParTopTxt(p), 'Position', [p off(p) 0], 'String', sprintf('%.3g', procImp(p)));
        set(S.TxtMapImp(p), 'String', sprintf('impact: %.4g', procImp(p)));
        % ---- real-time coverage of the column and data-quality check ----
        fl = find([Inp.Proc] == p);
        if ~isempty(fl) && off(p) > 0
            isRT = strcmp({Inp(fl).DataType},'real-time');
            rtShare = sum(segH(fl(isRT))) / off(p);
            [~, im] = max(segH(fl));
            dom = Inp(fl(im));
            if strcmp(dom.DataType,'real-time'), mark = ''; else, mark = ' !'; end
            set(S.ParRtTxt(p), 'Position', [p off(p)+0.045*max(yMax,eps) 0], ...
                'String', sprintf('RT %.0f%%%s', 100*rtShare, mark));
            if ~strcmp(dom.DataType,'real-time')
                dqList{end+1} = sprintf('%s: %.0f%% from "%s" (%s)', S.Procs{p}, ...
                    100*segH(fl(im))/off(p), rtlca_util('trunc', dom.Nome,16), dom.DataType); %#ok<AGROW>
            end
        end
    end
    if isempty(dqList), S.LblDQ.Text = 'Data quality: the dominant flow of every process is measured in real time.';
    else, S.LblDQ.Text = ['Data quality: dominant flow NOT real-time in -> ' strjoin(dqList,' | ')]; end
    % ---- LCC stacked histogram per unit process ----
    offC = zeros(1,nP);
    for i = 1:nIn
        p = Inp(i).Proc; h = abs(costs(i));
        set(S.CostPatch(i), 'YData', [offC(p) offC(p) offC(p)+h offC(p)+h]);
        offC(p) = offC(p) + h;
    end
    for p = 1:nP
        hs = [capexP(p) labP(p) opxP(p)]*elapsedH;
        hs(4) = carbonP * sum(abs(imps([Inp.Proc] == p)));
        hp = [S.CostCapexP(p) S.CostLabP(p) S.CostOpxP(p) S.CostCarbP(p)];
        for q = 1:4
            set(hp(q), 'YData', [offC(p) offC(p) offC(p)+hs(q) offC(p)+hs(q)]);
            offC(p) = offC(p) + hs(q);
        end
        set(S.CostTopTxt(p), 'Position', [p offC(p) 0], 'String', sprintf('%.2f', offC(p)));
    end
    if max(offC) > 0, S.AxCostPar.YLim = [0 1.15*max(offC)]; end
    S.Kpi(5).Text = sprintf('%.2f', costTot);
    % ---- CED per unit process ----
    cedP = zeros(nP,2);
    for i = 1:nIn, cedP(Inp(i).Proc,:) = cedP(Inp(i).Proc,:) + abs(ced(i,:)); end
    for p = 1:nP
        set(S.CedNRP(p), 'YData', [0 0 cedP(p,1) cedP(p,1)]);
        set(S.CedRP(p),  'YData', [cedP(p,1) cedP(p,1) sum(cedP(p,:)) sum(cedP(p,:))]);
        set(S.CedTopTxt(p), 'Position', [p sum(cedP(p,:)) 0], 'String', sprintf('%.3g MJ', sum(cedP(p,:))));
    end
    if max(sum(cedP,2)) > 0, S.AxCed.YLim = [0 1.15*max(sum(cedP,2))]; end
    cedTot = sum(cedP(:));
    if cedTot > 0
        S.LblCED.Text = sprintf('CED total: %.4g MJ   |   renewable share %.0f%%', cedTot, 100*sum(cedP(:,2))/cedTot);
    end
    S.LblHdrR.Text = sprintf('%s  -  cycle %d', rtlca_util('trunc', S.Campaign,14), S.ExpN);
    % ---- ALARM: one unit process above 80% of the total impact ----
    if nP > 1 && totAll > 0
        for p = 1:nP
            share = off(p)/totAll;
            if share > 0.80
                set(S.MapRect(p),'EdgeColor',[0.85 0.10 0.10],'LineWidth',3);
                S.LblAlarm.Text = sprintf('ALARM: "%s" alone causes %.0f%% of the total impact (> 80%%)', ...
                                          S.Procs{p}, 100*share);
                if ~S.AlarmDone(p)
                    S.AlarmDone(p) = true;
                    rtlca_persist('addLog', fig, sprintf('  ALARM cycle %d, t=%.1f s: "%s" = %.0f%% of total impact', ...
                                        S.ExpN, tv(min(kEnd,S.NSteps)), S.Procs{p}, 100*share));
                    uialert(fig, sprintf(['Unit process "%s" is causing %.0f%% of the total ' ...
                        'impact: it dominates the environmental damage of the whole system. ' ...
                        'Check its flows in the PARETO tab.'], S.Procs{p}, 100*share), ...
                        'Dominant process alarm','Icon','warning');
                end
            elseif S.AlarmDone(p)
                set(S.MapRect(p),'EdgeColor',S.CmapIn(min(p,size(S.CmapIn,1)),:),'LineWidth',2);
            end
        end
    end

    % ---- mix bars + gauges + big readouts + KPI ----
    if useMix
        kNow = min(kEnd, S.NSteps);
        shNow = 100*S.ShareVec(kNow,:);
        for q = 1:numel(S.BarMix)
            set(S.BarMix(q),'YData',shNow(q));
        end
        title(S.AxMix, sprintf('Italian grid mix @ %s   cf=%.4g', ...
              datestr(S.MixStart + (tv(kNow)-tv(1))/86400,'dd/mm HH:MM'), cfMixVec(kNow)));
    end
    if nRt > 0
        vC = zeros(1,nRt); vI = zeros(1,nRt);
        for kx = 1:nRt
            vC(kx) = impCumRT(kx);
            if ~isnan(heldI(kx)), vI(kx) = heldI(kx); end
        end
        gauge_update(S.G1, vC);
        gauge_update(S.G2, vI);
        S.LblG1.Text = sprintf('%.5g', sum(vC));
        S.LblG2.Text = sprintf('%.5g', sum(vI));
    end
    S.Kpi(1).Text = sprintf('%.5g', sum(impsInst));
    S.Kpi(2).Text = sprintf('%.5g', cumTot);
    if statVal > 0
        S.Kpi(3).Text = sprintf('%+.1f%%', 100*(cumTot-statVal)/statVal);
    else
        S.Kpi(3).Text = '-';
    end
    S.Kpi(4).Text = sprintf('%d', hotN);
    if soglia > 0 && sum(impsInst) > soglia, S.Kpi(4).FontColor = [0.8 0.1 0.1];
    else, S.Kpi(4).FontColor = [0 0 0]; end
    S.LblStatus.Text = sprintf('Cycle %d: t = %.1f s (%d/%d)', ...
                               S.ExpN, tv(min(kEnd,S.NSteps)), kEnd, S.NSteps);
    drawnow limitrate;
    if ~isvalid(fig), return; end
    if ~getappdata(fig,'RUN'), break; end
end

if ~isvalid(fig), return; end
alarmDone = S.AlarmDone;
S = getappdata(fig,'S');
S.AlarmDone = alarmDone;
S.Idx = k; S.PrevCum = prevCum; S.HeldE = heldE; S.HeldI = heldI; S.HasEv = hasEv;
S.ImpCumRT = impCumRT; S.CostCumRT = costCumRT; S.CostDisr = costDisr; S.CedCumRT = cedCumRT;
S.Rec = rec;
S.HotN = hotN; S.CumTot = cumTot;
S.BtnStart.Enable='on'; S.BtnStop.Enable='off'; S.BtnNew.Enable='on';
if k > S.NSteps
    rtlca_persist('addLog', fig, sprintf('[%s] Cycle %d completed: total impact = %.6g', S.Campaign, S.ExpN, cumTot));
    procImp = zeros(1,numel(S.Procs));
    for i = 1:numel(S.Inputs)
        procImp(S.Inputs(i).Proc) = procImp(S.Inputs(i).Proc) + imps(i);
    end
    for p = 1:numel(S.Procs)
        rtlca_persist('addLog', fig, sprintf('   %-16s = %.6g', rtlca_util('trunc', S.Procs{p},16), procImp(p)));
    end
    if statVal > 0
        dperc = 100*(cumTot-statVal)/statVal;
        rtlca_persist('addLog', fig, sprintf('   Delta%% vs static LCA = %+.2f%%  (RT=%.6g, static=%.6g)', ...
                            dperc, cumTot, statVal));
    end
    if S.HotN > 0
        rtlca_persist('addLog', fig, sprintf('   Campaign hotspots so far: %d', S.HotN));
    end
    % ---- LCC summary of the cycle ----
    elapsedH = (S.Tvec(end)-S.Tvec(1))/3600;
    rtlca_persist('addLog', fig, sprintf('   LCC total = %.2f EUR: energy %.2f | capital %.2f | labour %.2f | other OPEX %.2f | carbon %.2f | disruption %.2f', ...
           costTot, sum(costCumRT), sum(capexP)*elapsedH, sum(labP)*elapsedH, sum(opxP)*elapsedH, ...
           carbonP*sum(abs(imps)), costDisr));
    rtlca_persist('addLog', fig, sprintf('   Cost per product unit = %.4f EUR/unit (%g units per cycle)', ...
           costTot/max(S.UnitsPerCycle,1), S.UnitsPerCycle));
    rtlca_persist('addLog', fig, sprintf('   CED = %.4g MJ (non-renewable %.4g, renewable %.4g)', ...
           sum(ced(:)), sum(ced(:,1)), sum(ced(:,2))));
    % ---- DATA QUALITY message: dominant flow of a process not real-time ----
    msg = {};
    for p = 1:numel(S.Procs)
        fl = find([S.Inputs.Proc] == p);
        if isempty(fl), continue; end
        segp = abs(imps(fl)); totp = sum(segp);
        if totp <= 0, continue; end
        [mx, im] = max(segp);
        dom = S.Inputs(fl(im));
        rtShare = sum(segp(strcmp({S.Inputs(fl).DataType},'real-time'))) / totp;
        if ~strcmp(dom.DataType,'real-time')
            msg{end+1} = sprintf(['- "%s": %.0f%% of its impact comes from "%s", a %s datum; ' ...
                'only %.0f%% of the column is measured in real time. The dominant contribution ' ...
                'therefore carries the higher uncertainty of a non-measured datum: to increase ' ...
                'confidence in the real impact of this process, this flow should be instrumented ' ...
                'and acquired in real time (or its data quality improved).'], ...
                S.Procs{p}, 100*mx/totp, dom.Nome, dom.DataType, 100*rtShare); %#ok<AGROW>
            rtlca_persist('addLog', fig, sprintf('   DATA QUALITY "%s": dominant flow "%s" (%s) %.0f%%, RT coverage %.0f%%', ...
                   S.Procs{p}, rtlca_util('trunc', dom.Nome,16), dom.DataType, 100*mx/totp, 100*rtShare));
        end
    end
    if ~isempty(msg)
        uialert(fig, strjoin(msg, newline), 'Data quality: dominant contribution not real-time', 'Icon','info');
    end
    % ---- PERSISTENCE (Module 4): cycle summary + per-instant series ----
    R = struct();
    R.Campaign = S.Campaign; R.Cycle = S.ExpN;
    R.Category = S.ColLabels{S.DDImpG.Value};
    R.Processes = S.Procs; R.ProcImpact = procImp;
    R.TotalImpact = cumTot; R.StaticLCA = statVal;
    if statVal > 0, R.DeltaPerc = 100*(cumTot-statVal)/statVal; else, R.DeltaPerc = NaN; end
    R.FlowImpact = imps; R.FlowCost = costs; R.FlowCED = ced;
    R.CostTotal = costTot; R.CostEnergy = sum(costCumRT); R.CostDisruption = costDisr;
    R.CostPerUnit = costTot/max(S.UnitsPerCycle,1);
    R.CEDTotal = sum(ced(:)); R.CEDRenewable = sum(ced(:,2));
    R.Hotspots = hotN; R.DataQualityNotes = msg;
    if isfinite(S.MixStart), R.MixStart = datestr(S.MixStart,'yyyy-mm-dd HH:MM'); else, R.MixStart = ''; end
    R.Timestamp = datestr(now,'yyyy-mm-dd HH:MM:SS');
    if isempty(S.Results), S.Results = R; else, S.Results(end+1) = R; end
    S.Series{S.ExpN} = rec;
    rtlca_persist('addLog', fig, sprintf('   Cycle %d stored in the results archive (press SAVE RESULTS to write it to file).', S.ExpN));
    S.TOffset = S.TOffset + (S.Tvec(end)-S.Tvec(1)) + max(1, 0.03*(S.Tvec(end)-S.Tvec(1)));
    S.LblStatus.Text = sprintf('Cycle %d completed. Press NEW CYCLE for the next run.', S.ExpN);
else
    S.LblStatus.Text = sprintf('Cycle %d paused (%d/%d): press START to resume.', S.ExpN, k-1, S.NSteps);
end
setappdata(fig,'S',S);
setappdata(fig,'RUN',false);
end


function onNewExp(src,~)
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
if S.Idx <= S.NSteps && S.Idx > 1
    uialert(fig,'The current cycle is not finished: complete it or stop it.','New cycle');
    return;
end
S.ExpN = S.ExpN + 1;
setappdata(fig,'S',S);
if ~rtlca_sources('promptQS', fig)
    S = getappdata(fig,'S'); S.ExpN = S.ExpN - 1; setappdata(fig,'S',S);
    return;
end
S = getappdata(fig,'S');
S.LblExp.Text = sprintf('Cycle %d', S.ExpN);
S.LblStatus.Text = sprintf('Cycle %d ready: press START.', S.ExpN);
setappdata(fig,'S',S);
resetCycle(fig);
end


function onClose(src,~)
setappdata(src,'RUN',false);
delete(src);
end


% #########################################################################
%  FILE READING AND UTILITIES
% #########################################################################


function G = gauge_create(ax, lims, ttl, cmap, names)
nN = numel(names);
cla(ax); hold(ax,'on');
seg = {[0 0.5],[0.5 0.8],[0.8 1]};
col = {[0.30 0.75 0.30],[0.95 0.85 0.25],[0.85 0.33 0.10]};
for i = 1:3
    aa = linspace(pi*(1-seg{i}(1)), pi*(1-seg{i}(2)), 60);
    plot(ax, 0.98*cos(aa), 0.98*sin(aa), '-', 'Color', col{i}, 'LineWidth', 6);
end
th = linspace(pi,0,200);
plot(ax, cos(th), sin(th), 'k-', 'LineWidth', 1);
for f = 0:0.25:1
    a = pi*(1-f);
    plot(ax, [0.86 1.02]*cos(a), [0.86 1.02]*sin(a), 'k-', 'LineWidth', 1);
    text(ax, 1.20*cos(a), 1.20*sin(a), sprintf('%.3g', lims(1)+f*(lims(2)-lims(1))), ...
         'HorizontalAlignment','center','FontSize',9);
end
G.lims = lims;
G.len = zeros(1,nN); G.needle = gobjects(1,nN); G.tip = gobjects(1,nN); G.txt = gobjects(1,nN);
for i = 1:nN
    c = cmap(min(i,size(cmap,1)),:);
    G.len(i)    = max(0.35, 0.86 - 0.13*(i-1));
    G.needle(i) = plot(ax, [0 0], [0 G.len(i)], '-', 'Color', c, 'LineWidth', 4);
    G.tip(i)    = plot(ax, 0, G.len(i), 'o', 'Color', c, 'MarkerFaceColor', c, 'MarkerSize', 6);
    G.txt(i)    = text(ax, -1.35, -0.24-0.15*(i-1), '', 'Color', c, 'FontWeight','bold', ...
                       'FontSize',11,'HorizontalAlignment','left','Interpreter','none');
end
G.names = names;
plot(ax, 0, 0, 'ko', 'MarkerFaceColor','k', 'MarkerSize', 5);
ax.XLim = [-1.5 1.5];
ax.YLim = [-0.24-0.15*nN-0.10, 1.42];
ax.DataAspectRatio = [1 1 1];
set(ax,'XTick',[],'YTick',[],'XColor','w','YColor','w','Box','off');
title(ax, ttl, 'FontSize', 12);
end


function gauge_update(G, vals)
if isempty(G.needle) || ~isvalid(G.needle(1)), return; end
rng = G.lims(2) - G.lims(1);
if rng <= 0, rng = 1; end
for i = 1:numel(G.needle)
    if i <= numel(vals), v = vals(i); else, v = 0; end
    if ~isfinite(v), v = 0; end
    f = max(0, min(1, (v - G.lims(1))/rng));
    a = pi*(1-f);
    L = G.len(i);
    set(G.needle(i), 'XData', [0 L*cos(a)], 'YData', [0 L*sin(a)]);
    set(G.tip(i),    'XData', L*cos(a),     'YData', L*sin(a));
    set(G.txt(i),    'String', sprintf('%s = %.4g', rtlca_util('trunc', G.names{i},14), v));
end
end


