function varargout = rtlca_ui(action, varargin)
% rtlca_ui  -  RT-LCA dashboard module: interface: window layout, tab bar, step navigation (accordion), process map
% Call as  rtlca_ui('functionName', args...)  : dispatches to the local function.
% Functions: buildUI, onTabSel, showTab, onStepClick, gotoStep, setEnable, setVisibleChildren, syncZone, drawMap, flowStyle, flowLabel
f = str2func(action);
[varargout{1:nargout}] = f(varargin{:});
end


function buildUI(fig)
S = getappdata(fig,'S');
z = S.Z;
if z < 0.85, fs = 11; else, fs = 13; end
cPri = [0.13 0.45 0.71]; cGo  = [0.13 0.62 0.41];
cStop= [0.80 0.29 0.22]; cSec = [0.90 0.94 0.98];
cTxt = [0.10 0.28 0.45]; wTxt = [1 1 1];
S.cPri=cPri; S.cSec=cSec; S.cTxt=cTxt;

SP = uipanel(fig,'Title','  GUIDED WORKFLOW','Position',z*[10 10 355 880], ...
             'BackgroundColor',[0.95 0.96 0.98],'ForegroundColor',cPri,'FontWeight','bold', ...
             'BorderType','line');
S.LblStep = uilabel(SP,'Text','','Position',z*[10 846 335 18], ...
                    'FontSize',fs,'FontWeight','bold','FontColor',cPri);

% ---- STEP 1: DATABASE ----
S.P1 = uipanel(SP,'Title','Step 1 - Database','Position',z*[10 792 335 52], ...
               'BackgroundColor',[1 1 1]);
S.EFDb = uieditfield(S.P1,'text','Value','dataset.xlsx','Position',z*[10 4 195 22]);
S.BtnLoadDb = uibutton(S.P1,'Text','LOAD','Position',z*[213 2 110 26], ...
                       'FontWeight','bold','BackgroundColor',cPri,'FontColor',wTxt, ...
                       'ButtonPushedFcn',@(s,e) rtlca_system('onLoadDb',s,e));

% ---- STEP 2: SYSTEM DEFINITION (Goal & Scope) ----
S.P2 = uipanel(SP,'Title','Step 2 - System definition','Position',z*[10 674 335 114], ...
               'BackgroundColor',[1 1 1]);
uilabel(S.P2,'Text','Impact category (whole study):','Position',z*[10 72 180 20]);
S.DDImpG = uidropdown(S.P2,'Items',{'(load the database)'},'Position',z*[10 48 315 22]);
S.BtnAddP = uibutton(S.P2,'Text','+','Position',z*[10 18 44 26], ...
                     'FontSize',18,'FontWeight','bold','BackgroundColor',cGo,'FontColor',wTxt, ...
                     'Tooltip','Add a unit process (asks its name)','ButtonPushedFcn',@(s,e) rtlca_system('onAddProc',s,e));
S.BtnDelP = uibutton(S.P2,'Text','-','Position',z*[60 18 44 26], ...
                     'FontSize',18,'FontWeight','bold','BackgroundColor',cSec,'FontColor',cTxt, ...
                     'Tooltip','Remove the last unit process','ButtonPushedFcn',@(s,e) rtlca_system('onDelProc',s,e));
uilabel(S.P2,'Text','unit process','Position',z*[110 20 80 22],'FontAngle','italic');
S.BtnProcs = uibutton(S.P2,'Text','NEXT  >','Position',z*[215 18 110 26], ...
                      'FontWeight','bold','BackgroundColor',cPri,'FontColor',wTxt, ...
                      'ButtonPushedFcn',@(s,e) rtlca_system('onProcsNext',s,e));
S.LblChain = uilabel(S.P2,'Text','(no processes yet: press +)','Position',z*[10 0 315 18], ...
                     'FontAngle','italic');

% ---- STEP 3: FLOWS (LCI) ----
S.P3 = uipanel(SP,'Title','Step 3 - Flows of each process (LCI)', ...
               'Position',z*[10 330 335 462],'BackgroundColor',[1 1 1]);
uilabel(S.P3,'Text','Process:','Position',z*[10 416 55 22],'FontWeight','bold');
S.DDProcU = uidropdown(S.P3,'Items',{'(define processes)'},'Position',z*[68 416 155 22]);
S.BGDir = uibuttongroup(S.P3,'BorderType','none','BackgroundColor',[1 1 1], ...
                        'Position',z*[228 416 100 22]);
S.RbIn  = uiradiobutton(S.BGDir,'Text','In','Position',z*[2 1 42 20],'Value',true);
S.RbOut = uiradiobutton(S.BGDir,'Text','Out','Position',z*[48 1 50 20]);
S.BGData = uibuttongroup(S.P3,'BorderType','none','BackgroundColor',[1 1 1], ...
                         'Position',z*[10 370 315 44],'SelectionChangedFcn',@(s,e) rtlca_system('onDataTypeChanged',s,e));
S.RbStat = uiradiobutton(S.BGData,'Text','static','Position',z*[5 23 100 20],'Value',true);
S.RbQS   = uiradiobutton(S.BGData,'Text','quasi-static','Position',z*[115 23 130 20]);
S.RbDin  = uiradiobutton(S.BGData,'Text','dynamic','Position',z*[5 1 100 20]);
S.RbRT   = uiradiobutton(S.BGData,'Text','real-time','Position',z*[115 1 130 20]);
S.BGTipo = uibuttongroup(S.P3,'BorderType','none','BackgroundColor',[1 1 1], ...
                         'Position',z*[10 346 200 22],'SelectionChangedFcn',@(s,e) rtlca_system('onTipoChanged',s,e));
S.RbMat = uiradiobutton(S.BGTipo,'Text','Matter','Position',z*[5 1 95 20],'Value',true);
S.RbEne = uiradiobutton(S.BGTipo,'Text','Energy','Position',z*[105 1 95 20]);
S.LblAuto = uilabel(S.P3,'Text','','Position',z*[215 346 110 22],'FontAngle','italic');
uilabel(S.P3,'Text','filter:','Position',z*[10 320 38 22]);
S.EFKw = uieditfield(S.P3,'text','Value','','Position',z*[50 320 275 22], ...
                     'ValueChangedFcn',@(s,e) rtlca_system('onFilter',s,e));
S.DDProc = uidropdown(S.P3,'Items',{'(load the database)'},'Position',z*[10 294 315 22], ...
                      'ValueChangedFcn',@(s,e) rtlca_system('onProcChanged',s,e));
S.LblQty = uilabel(S.P3,'Text','Quantity:','Position',z*[10 266 170 20],'FontWeight','bold');
S.EFQty = uieditfield(S.P3,'numeric','Value',1,'Position',z*[185 266 140 22]);
S.PLaw = uipanel(S.P3,'BorderType','none','Position',z*[10 208 315 84], ...
                 'BackgroundColor',[1 1 1],'Visible','off');
uilabel(S.PLaw,'Text','Variation law v(t)  (never constant)','Position',z*[0 64 315 18], ...
        'FontWeight','bold');
S.DDLaw = uidropdown(S.PLaw,'Items',{'Linear:  a + b*t','Sinusoidal:  a + b*sin(w*t)', ...
                     'Exponential:  a*exp(b*t)','Custom:  f(t)'}, ...
                     'Position',z*[0 38 180 22],'ValueChangedFcn',@(s,e) rtlca_system('onLawType',s,e));
uilabel(S.PLaw,'Text','a','Position',z*[188 38 10 22]);
S.EFa = uieditfield(S.PLaw,'numeric','Value',10,'Position',z*[199 38 55 22]);
uilabel(S.PLaw,'Text','b','Position',z*[258 38 10 22]);
S.EFb = uieditfield(S.PLaw,'numeric','Value',2,'Position',z*[269 38 55 22]);
uilabel(S.PLaw,'Text','w','Position',z*[0 12 12 22]);
S.EFw = uieditfield(S.PLaw,'numeric','Value',0.05,'Position',z*[14 12 55 22]);
uilabel(S.PLaw,'Text','f(t)','Position',z*[76 12 24 22]);
S.EFexpr = uieditfield(S.PLaw,'text','Value','10 + 5*sin(0.05*t)','Position',z*[102 12 223 22], ...
                       'Enable','off');
S.BtnAdd = uibutton(S.P3,'Text','+ ADD FLOW','Position',z*[10 176 155 26], ...
                    'FontWeight','bold','BackgroundColor',cSec,'FontColor',cTxt, ...
                    'ButtonPushedFcn',@(s,e) rtlca_system('onAddInput',s,e));
S.BtnDel = uibutton(S.P3,'Text','REMOVE','Position',z*[175 176 150 26], ...
                    'BackgroundColor',cSec,'FontColor',cTxt,'ButtonPushedFcn',@(s,e) rtlca_system('onRemoveInput',s,e));
S.LstIn = uilistbox(S.P3,'Items',{'(no flows yet)'},'Position',z*[10 34 315 136]);
S.BtnEnd = uibutton(S.P3,'Text','FINISH FLOWS  >','Position',z*[10 4 315 26], ...
                    'FontWeight','bold','BackgroundColor',cPri,'FontColor',wTxt, ...
                    'ButtonPushedFcn',@(s,e) rtlca_system('onEndFlows',s,e));

% ---- STEP 4: COSTS (LCC) ----
S.PC = uipanel(SP,'Title','Step 4 - Costs and prices (LCC)','Position',z*[10 268 335 58], ...
               'BackgroundColor',[1 1 1]);
S.BtnCosts = uibutton(S.PC,'Text','ENTER COSTS','Position',z*[10 6 150 26], ...
                      'FontWeight','bold','BackgroundColor',cSec,'FontColor',cTxt, ...
                      'ButtonPushedFcn',@(s,e) rtlca_costs('onEnterCosts',s,e));
S.BtnCostNext = uibutton(S.PC,'Text','NEXT  >','Position',z*[165 6 160 26], ...
                         'FontWeight','bold','BackgroundColor',cPri,'FontColor',wTxt, ...
                         'ButtonPushedFcn',@(s,e) rtlca_costs('onCostsNext',s,e));

% ---- STEP 5: RT SOURCE, GRID MIX, ENERGY PRICE (three clear sections) ----
S.P4 = uipanel(SP,'Title','Step 5 - Real-time source, grid mix, price', ...
               'Position',z*[10 86 335 246],'BackgroundColor',[1 1 1]);
uilabel(S.P4,'Text','A.  Acquisition file  (energy channels auto-detected)', ...
        'Position',z*[10 206 315 16],'FontWeight','bold','FontColor',cTxt);
S.EFRt = uieditfield(S.P4,'text','Value','test_imbriglio_1.xlsx','Position',z*[10 180 205 22]);
S.BtnRtLoad = uibutton(S.P4,'Text','LOAD RT','Position',z*[222 178 103 26], ...
                       'FontWeight','bold','BackgroundColor',cSec,'FontColor',cTxt, ...
                       'ButtonPushedFcn',@(s,e) rtlca_sources('onLoadRT',s,e));
S.LblRtInfo = uilabel(S.P4,'Text','no file loaded yet','Position',z*[10 158 315 18], ...
                      'FontAngle','italic','FontColor',[0.45 0.45 0.45]);
uilabel(S.P4,'Text','B.  Italian grid mix (Terna) and clock of the cycle', ...
        'Position',z*[10 132 315 16],'FontWeight','bold','FontColor',cTxt);
S.EFTerna = uieditfield(S.P4,'text','Value','terna_agosto.xlsx','Position',z*[10 106 205 22]);
S.BtnMix = uibutton(S.P4,'Text','LOAD MIX','Position',z*[222 104 103 26], ...
                    'FontWeight','bold','BackgroundColor',cSec,'FontColor',cTxt, ...
                    'ButtonPushedFcn',@(s,e) rtlca_sources('onLoadMix',s,e));
uilabel(S.P4,'Text','day:','Position',z*[10 80 30 22]);
S.DDDay  = uidropdown(S.P4,'Items',{'(load mix)'},'Position',z*[42 80 110 22], ...
                      'ValueChangedFcn',@(s,e) rtlca_sources('onDayChanged',s,e));
uilabel(S.P4,'Text','time:','Position',z*[160 80 34 22]);
S.DDTime = uidropdown(S.P4,'Items',{'--:--'},'Position',z*[196 80 66 22], ...
                      'ValueChangedFcn',@(s,e) rtlca_sources('onTimeChanged',s,e));
S.LblCfMix = uilabel(S.P4,'Text','cf: -','Position',z*[268 80 57 22],'FontWeight','bold', ...
                     'FontColor',cPri);
uilabel(S.P4,'Text','C.  Energy price file, 15 min  (optional, for the LCC)', ...
        'Position',z*[10 54 315 16],'FontWeight','bold','FontColor',cTxt);
S.EFPrice = uieditfield(S.P4,'text','Value','energy-charts_La_produzione_di_elettricità_e_spot_price_in_Italia_in_settimana_36_2026.xlsx', ...
                        'Position',z*[10 28 205 22]);
S.BtnPrice = uibutton(S.P4,'Text','LOAD PRICE','Position',z*[222 26 103 26], ...
                      'FontWeight','bold','BackgroundColor',cSec,'FontColor',cTxt, ...
                      'ButtonPushedFcn',@(s,e) rtlca_sources('onLoadPrice',s,e), ...
                      'Tooltip','Zonal day-ahead price (energy-charts export): real-time economic datum');
S.BtnConfirm = uibutton(S.P4,'Text','CONFIRM  >','Position',z*[10 2 315 22], ...
                        'FontWeight','bold','BackgroundColor',cPri,'FontColor',wTxt, ...
                        'ButtonPushedFcn',@(s,e) rtlca_sources('onConfirm',s,e));

% ---- STEP 6: RUN (four clean rows) ----
S.P5 = uipanel(SP,'Title','Step 6 - Run the campaign','Position',z*[10 8 335 186], ...
               'BackgroundColor',[1 1 1]);
uilabel(S.P5,'Text','Campaign:','Position',z*[10 142 70 22]);
S.EFCamp = uieditfield(S.P5,'text','Value','Campaign_1','Position',z*[82 142 150 22]);
S.LblExp = uilabel(S.P5,'Text','Cycle 0','Position',z*[240 142 85 22], ...
                   'FontWeight','bold','FontColor',cPri,'HorizontalAlignment','right');
uilabel(S.P5,'Text','Static LCA value:','Position',z*[10 112 120 22]);
S.EFStat = uieditfield(S.P5,'numeric','Value',0,'Position',z*[135 112 90 22], ...
                       'Tooltip','Total cycle impact from static LCA (0 = no comparison)');
uilabel(S.P5,'Text','(0 = off)','Position',z*[232 112 93 22],'FontAngle','italic', ...
        'FontColor',[0.5 0.5 0.5]);
uilabel(S.P5,'Text','Hotspot threshold:','Position',z*[10 84 120 22]);
S.EFSoglia = uieditfield(S.P5,'numeric','Value',0,'Position',z*[135 84 90 22], ...
                         'Tooltip','Threshold on total instantaneous impact (0 = off)');
uilabel(S.P5,'Text','(0 = off)','Position',z*[232 84 93 22],'FontAngle','italic', ...
        'FontColor',[0.5 0.5 0.5]);
S.BtnStart = uibutton(S.P5,'Text','START','Position',z*[10 46 100 30], ...
                      'FontWeight','bold','BackgroundColor',cGo,'FontColor',wTxt, ...
                      'ButtonPushedFcn',@(s,e) rtlca_engine('onStartExp',s,e));
S.BtnStop  = uibutton(S.P5,'Text','STOP','Position',z*[118 46 80 30], ...
                      'FontWeight','bold','BackgroundColor',cStop,'FontColor',wTxt, ...
                      'ButtonPushedFcn',@(s,e) rtlca_engine('onStop',s,e));
S.BtnNew   = uibutton(S.P5,'Text','NEW CYCLE','Position',z*[206 46 119 30], ...
                      'FontWeight','bold','BackgroundColor',cSec,'FontColor',cTxt, ...
                      'ButtonPushedFcn',@(s,e) rtlca_engine('onNewExp',s,e));
S.BtnSave = uibutton(S.P5,'Text','SAVE RESULTS  (Excel + MAT)','Position',z*[10 8 315 30], ...
                     'FontWeight','bold','BackgroundColor',cSec,'FontColor',cTxt, ...
                     'Tooltip','Stores system, cycle results, per-instant series and log (Module 4 persistence)', ...
                     'ButtonPushedFcn',@(s,e) rtlca_persist('onSaveResults',s,e));

% ------------------------- RIGHT AREA ------------------------------------
% ---- application header bar ----
hdr = uipanel(fig,'Position',z*[375 852 1150 40],'BackgroundColor',[0.10 0.22 0.36],'BorderType','none');
uilabel(hdr,'Text','RT-LCA / LCC PROCESS DASHBOARD','Position',z*[14 8 520 24], ...
        'FontSize',fs+3,'FontWeight','bold','FontColor',[1 1 1]);
uilabel(hdr,'Text','real-time life cycle assessment & costing of unit processes  |  ISO 14040/14044', ...
        'Position',z*[540 10 440 20],'FontSize',fs-2,'FontColor',[0.80 0.87 0.95]);
S.LblHdrR = uilabel(hdr,'Text','no campaign','Position',z*[1000 10 140 20], ...
        'FontSize',fs-2,'FontWeight','bold','FontColor',[1 1 1],'HorizontalAlignment','right');

% ---- KPI cards ----
kpiT = {'INSTANTANEOUS IMPACT','CUMULATIVE IMPACT','DELTA% VS STATIC LCA', ...
        'HOTSPOTS DETECTED','CUMULATIVE COST [EUR]'};
kpiC = {[0.10 0.55 0.55],[0 0.35 0.65],[0.55 0.30 0.65],[0.80 0.29 0.22],[0.10 0.45 0.20]};
S.Kpi = gobjects(1,5);
for i = 1:5
    px = 375 + (i-1)*232;
    pk = uipanel(fig,'Position',z*[px 792 222 54],'BackgroundColor',[1 1 1],'BorderType','line');
    uilabel(pk,'Text',kpiT{i},'Position',z*[8 32 210 16],'FontSize',fs-4,'FontColor',[0.45 0.45 0.45]);
    S.Kpi(i) = uilabel(pk,'Text','-','Position',z*[8 2 210 28], ...
                       'FontSize',round(17*max(z,0.8)),'FontWeight','bold','FontColor',kpiC{i});
end
S.LblStatus = uilabel(fig,'Text','Welcome: start from Step 1 on the left.', ...
                      'Position',z*[375 772 1150 18],'FontSize',fs-1,'FontColor',[0.25 0.25 0.25]);

% ---- browser-like tab bar ----
tabNames = {'MAP','IMPACT','ENERGY','PARETO','LCC','CED'};
S.TabBtn = gobjects(1,6);
for k = 1:6
    S.TabBtn(k) = uibutton(fig,'Text',tabNames{k},'Position',z*[375+(k-1)*126 746 122 24], ...
        'FontWeight','bold','ButtonPushedFcn',@onTabSel,'UserData',k);
end

% ---- tab panels (stacked, Visible toggled) ----
S.Tab = gobjects(1,6);
for k = 1:6
    S.Tab(k) = uipanel(fig,'Position',z*[375 12 1150 730],'BackgroundColor',[1 1 1], ...
                       'Visible','off','BorderType','line');
end

% TAB 1: MAP (process blocks + log)
S.AxMap = uiaxes(S.Tab(1),'Position',z*[10 295 1125 425]);
title(S.AxMap,'Unit processes (flow order) - live impact per process');
S.TxtLog = uitextarea(S.Tab(1),'Position',z*[10 10 1125 280],'Editable','off', ...
                      'FontName','Courier New', ...
                      'Value',{'CAMPAIGN AND HOTSPOT LOG','-------------------------'});

% TAB 2: IMPACT (big gauges + readouts + impact profiles)
S.LblG1 = uilabel(S.Tab(2),'Text','-','Position',z*[60 678 460 40], ...
                  'FontSize',round(28*max(z,0.8)),'FontWeight','bold', ...
                  'FontColor',[0 0.35 0.65],'HorizontalAlignment','center');
S.AxG1  = uiaxes(S.Tab(2),'Position',z*[30 330 520 345]);
S.LblG2 = uilabel(S.Tab(2),'Text','-','Position',z*[630 678 460 40], ...
                  'FontSize',round(28*max(z,0.8)),'FontWeight','bold', ...
                  'FontColor',[0.10 0.55 0.55],'HorizontalAlignment','center');
S.AxG2  = uiaxes(S.Tab(2),'Position',z*[600 330 520 345]);
S.AxImp = uiaxes(S.Tab(2),'Position',z*[30 15 530 305]);
title(S.AxImp,'INSTANTANEOUS impact + threshold');
xlabel(S.AxImp,'cycle time [s]'); grid(S.AxImp,'on');
S.AxCum = uiaxes(S.Tab(2),'Position',z*[600 15 525 305]);
title(S.AxCum,'CUMULATIVE impact vs static LCA');
xlabel(S.AxCum,'cycle time [s]'); grid(S.AxCum,'on');

% TAB 3: ENERGY (values, sample-and-hold, grid mix)
S.AxVal = uiaxes(S.Tab(3),'Position',z*[15 390 1120 330]);
title(S.AxVal,'Values instant by instant (cycles are appended)');
xlabel(S.AxVal,'campaign time [s]'); ylabel(S.AxVal,'value [own unit]');
grid(S.AxVal,'on');
S.AxEins = uiaxes(S.Tab(3),'Position',z*[15 15 550 360]);
title(S.AxEins,'Instantaneous energy (sample-and-hold)');
xlabel(S.AxEins,'cycle time [s]'); grid(S.AxEins,'on');
S.AxMix = uiaxes(S.Tab(3),'Position',z*[590 15 545 360]);
title(S.AxMix,'Italian grid mix'); ylabel(S.AxMix,'share [%]');
grid(S.AxMix,'on');

% TAB 4: PARETO (stacked contribution histogram per unit process)
S.LblAlarm = uilabel(S.Tab(4),'Text','','Position',z*[50 696 1050 24], ...
                     'FontSize',fs,'FontWeight','bold','FontColor',[0.80 0.10 0.10]);
S.LblDQ = uilabel(S.Tab(4),'Text','','Position',z*[50 672 1050 22], ...
                  'FontSize',fs-1,'FontWeight','bold','FontColor',[0.80 0.45 0.05]);
S.AxPar = uiaxes(S.Tab(4),'Position',z*[50 30 1050 638]);
title(S.AxPar,'Contribution analysis per unit process (blue % = share measured in real time)');
grid(S.AxPar,'on');

% TAB 5: LCC (cost per unit process, split by cost item + cumulative cost)
S.AxCostPar = uiaxes(S.Tab(5),'Position',z*[50 375 1050 340]);
title(S.AxCostPar,'Real-time LCC: cost per unit process [EUR], split by cost item');
grid(S.AxCostPar,'on');
S.AxCostCum = uiaxes(S.Tab(5),'Position',z*[50 30 1050 330]);
title(S.AxCostCum,'Cumulative cost of the cycle [EUR]');
xlabel(S.AxCostCum,'cycle time [s]'); grid(S.AxCostCum,'on');

% TAB 6: CED - Cumulative Energy Demand (dataset columns, MJ)
S.LblCED = uilabel(S.Tab(6),'Text','CED: -','Position',z*[50 676 1050 40], ...
                   'FontSize',round(24*max(z,0.8)),'FontWeight','bold','FontColor',[0.45 0.30 0.10], ...
                   'HorizontalAlignment','center');
S.AxCed = uiaxes(S.Tab(6),'Position',z*[50 340 1050 330]);
title(S.AxCed,'Cumulative Energy Demand per unit process [MJ]: non-renewable vs renewable (Idemat CED columns)');
grid(S.AxCed,'on');
S.AxCedCum = uiaxes(S.Tab(6),'Position',z*[50 30 1050 295]);
title(S.AxCedCum,'Cumulative CED of the cycle [MJ]');
xlabel(S.AxCedCum,'cycle time [s]'); grid(S.AxCedCum,'on');

S.PH = [66 128 476 72 260 200];   % +14 px on top of each panel: room for the header button       % full heights of the six step panels
% clickable step headers (replace the panel titles): tap a reached step to reopen it
pnl = {S.P1,S.P2,S.P3,S.PC,S.P4,S.P5};
S.HdrBtn = gobjects(1,6);
for p = 1:6
    pnl{p}.Title = '';
    S.HdrBtn(p) = uibutton(pnl{p},'Text','','Position',z*[0 S.PH(p)-22 335 22], ...
        'HorizontalAlignment','left','FontWeight','bold','Tag','hdr', ...
        'UserData',p,'ButtonPushedFcn',@onStepClick);
end
setappdata(fig,'S',S);
end


function onTabSel(src,~)
showTab(ancestor(src,'figure'), src.UserData);
end


function showTab(fig, k)
S = getappdata(fig,'S');
for i = 1:6
    if i == k
        S.Tab(i).Visible = 'on';
        S.TabBtn(i).BackgroundColor = [1 1 1]; S.TabBtn(i).FontColor = S.cPri;
    else
        S.Tab(i).Visible = 'off';
        S.TabBtn(i).BackgroundColor = [0.88 0.90 0.93]; S.TabBtn(i).FontColor = [0.40 0.40 0.40];
    end
end
setappdata(fig,'S',S);
end


function onStepClick(src,~)
% Navigation by tapping a step header: any already-reached step can be
% reopened. Going back below Step 6 after a confirmation invalidates it:
% the campaign must be CONFIRMed again before running (inputs may change).
fig = ancestor(src,'figure'); S = getappdata(fig,'S');
k = src.UserData;
if getappdata(fig,'RUN')
    S.LblStatus.Text = 'Stop the running cycle before changing step.'; setappdata(fig,'S',S); return;
end
if k > S.MaxStep
    S.LblStatus.Text = sprintf('Step %d is not reachable yet: complete the previous steps first.', k);
    setappdata(fig,'S',S); return;
end
if k == S.Step, return; end
if k < 6 && S.ConfigDone
    S.ConfigDone = false;
    rtlca_persist('addLog', fig, sprintf('Configuration reopened at Step %d: press CONFIRM (Step 5) again before running.', k));
end
setappdata(fig,'S',S);
gotoStep(fig,k);
S = getappdata(fig,'S');
if k == 2 && S.Loaded, rtlca_system('applyFilter', fig); end
S.LblStatus.Text = sprintf('Reopened Step %d. Changes here require CONFIRM again before START.', k);
setappdata(fig,'S',S);
end


function gotoStep(fig, k)
% Accordion navigation. To keep it fast, only the two panels that change
% state (the one being closed and the one being opened) get their controls
% enabled/disabled and shown/hidden; the others just move.
S = getappdata(fig,'S');
if isfield(S,'Step'), k0 = S.Step; else, k0 = 0; end
S.Step = k;
nomi = {'Database','System definition','Flows (LCI)','Costs (LCC)','RT source, mix, price','Run the campaign'};
S.LblStep.Text = sprintf('Step %d of 6 - %s', k, nomi{k});
S.MaxStep = max(S.MaxStep, k);
pnl = {S.P1,S.P2,S.P3,S.PC,S.P4,S.P5};
z = S.Z; y = 842;
if k0 == 0, toUpd = 1:6; else, toUpd = unique([k0 k]); end
% hide the closing panel's controls FIRST, so nothing overlaps while moving
for p = toUpd
    if p ~= k
        setVisibleChildren(pnl{p}, false);
        setEnable(pnl{p}, false);
    end
end
for p = 1:6
    if p == k, h = S.PH(p); else, h = 22; end
    pnl{p}.Position = z*[10 y-h 335 h];
    y = y - h - 5;
    if any(p == toUpd), S.HdrBtn(p).Position = z*[0 h-22 335 22]; end
    base = sprintf('  Step %d - %s', p, nomi{p});
    if p == k
        txt = ['>' base]; bg = [0.13 0.45 0.71]; fc = [1 1 1];
    elseif p <= S.MaxStep
        txt = [base '   (done)']; bg = [0.86 0.94 0.88]; fc = [0.10 0.45 0.28];
    else
        txt = base; bg = [0.93 0.93 0.93]; fc = [0.55 0.55 0.55];
    end
    if ~strcmp(S.HdrBtn(p).Text, txt), S.HdrBtn(p).Text = txt; end
    if ~isequal(S.HdrBtn(p).BackgroundColor, bg), S.HdrBtn(p).BackgroundColor = bg; end
    if ~isequal(S.HdrBtn(p).FontColor, fc), S.HdrBtn(p).FontColor = fc; end
end
% now open the active panel
setEnable(pnl{k}, true);
setVisibleChildren(pnl{k}, true);
setappdata(fig,'S',S);
if k == 3, syncZone(fig); end          % restores quantity/law visibility rule
end


function setEnable(container, tf)
if tf, v = 'on'; else, v = 'off'; end
ch = container.Children;
for i = 1:numel(ch)
    if isprop(ch(i),'Tag') && strcmp(ch(i).Tag,'hdr'), continue; end
    if isa(ch(i),'matlab.ui.container.Panel')
        setEnable(ch(i), tf);
    else
        try, ch(i).Enable = v; catch, end
    end
end
end


% #########################################################################
%  STEP 1: DATABASE
% #########################################################################


function setVisibleChildren(container, tf)
if tf, v = 'on'; else, v = 'off'; end
ch = container.Children;
for i = 1:numel(ch)
    if isprop(ch(i),'Tag') && strcmp(ch(i).Tag,'hdr'), continue; end
    try, ch(i).Visible = v; catch, end
end
end


function syncZone(fig)
S = getappdata(fig,'S');
dt = rtlca_util('curData', S);
switch dt
    case 'dynamic'
        S.LblQty.Visible = 'off'; S.EFQty.Visible = 'off';
        S.PLaw.Visible = 'on';  S.LblAuto.Text = '(law below)';
    case 'real-time'
        S.LblQty.Visible = 'off'; S.EFQty.Visible = 'off';
        S.PLaw.Visible = 'off'; S.LblAuto.Text = '(from source)';
    otherwise
        S.LblQty.Visible = 'on'; S.EFQty.Visible = 'on';
        S.PLaw.Visible = 'off'; S.LblAuto.Text = '';
end
setappdata(fig,'S',S);
end


function drawMap(fig, procImp)
% Block diagram: one block per unit process (flow order, sequential arrows),
% INPUT flows drawn as arrows entering from the top, OUTPUT flows as arrows
% leaving from the bottom, each with its name; live impact inside the block.
% Arrow style = taxonomy: real-time thick blue, static grey, quasi-static
% dashed, dynamic dash-dot.
S = getappdata(fig,'S');
nP = numel(S.Procs);
if nP == 0, return; end
cla(S.AxMap); hold(S.AxMap,'on');
cmapP = lines(max(nP,7));
S.TxtMapImp = gobjects(1,nP);
S.MapRect   = gobjects(1,nP);
yB = 0.55; hB = 0.30;                       % block bottom and height
for p = 1:nP
    S.MapRect(p) = rectangle(S.AxMap,'Position',[p-0.40 yB 0.80 hB], ...
              'Curvature',0.15,'FaceColor',[0.92 0.95 0.99], ...
              'EdgeColor',cmapP(p,:),'LineWidth',2, ...
              'ButtonDownFcn',@(s,e) rtlca_system('onBlockClick',s,e),'UserData',p,'PickableParts','all');
    text(S.AxMap, p, yB+0.21, S.Procs{p}, 'HorizontalAlignment','center', ...
         'FontWeight','bold','FontSize',11,'Interpreter','none', ...
         'ButtonDownFcn',@(s,e) rtlca_system('onBlockClick',s,e),'UserData',p);
    if isempty(procImp), s0 = 'impact: -';
    else, s0 = sprintf('impact: %.4g', procImp(p)); end
    S.TxtMapImp(p) = text(S.AxMap, p, yB+0.08, s0, 'HorizontalAlignment','center', ...
         'FontSize',10,'FontWeight','bold','Color',[0 0.35 0.65]);
    if p < nP                               % sequential link to the next block
        plot(S.AxMap, [p+0.40 p+0.56], [yB+0.15 yB+0.15], 'k-', 'LineWidth', 2);
        patch(S.AxMap, [p+0.56 p+0.56 p+0.61], [yB+0.12 yB+0.18 yB+0.15], 'k');
    end
    % ---- flows of this process ----
    if isempty(S.Inputs), continue; end
    fl = find([S.Inputs.Proc] == p);
    inI  = fl(strcmp({S.Inputs(fl).Dir},'Input'));
    outI = fl(strcmp({S.Inputs(fl).Dir},'Output'));
    for k = 1:numel(inI)                    % INPUTS: arrows entering from above
        x = p - 0.32 + 0.64*(k-0.5)/max(numel(inI),1);
        [col, ls, lw] = flowStyle(S.Inputs(inI(k)).DataType);
        plot(S.AxMap, [x x], [1.12 yB+hB+0.02], 'LineStyle',ls,'Color',col,'LineWidth',lw, ...
             'ButtonDownFcn',@(s,e) rtlca_system('onFlowClick',s,e),'UserData',inI(k),'PickableParts','all');
        patch(S.AxMap, [x-0.025 x+0.025 x], [yB+hB+0.06 yB+hB+0.06 yB+hB+0.01], col, 'EdgeColor',col, ...
              'ButtonDownFcn',@(s,e) rtlca_system('onFlowClick',s,e),'UserData',inI(k),'PickableParts','all');
        text(S.AxMap, x, 1.14, flowLabel(S.Inputs(inI(k))), 'Rotation',60, ...
             'HorizontalAlignment','left','VerticalAlignment','middle', ...
             'FontSize',8,'Color',col,'Interpreter','none', ...
             'ButtonDownFcn',@(s,e) rtlca_system('onFlowClick',s,e),'UserData',inI(k));
    end
    for k = 1:numel(outI)                   % OUTPUTS: arrows leaving from below
        x = p - 0.32 + 0.64*(k-0.5)/max(numel(outI),1);
        [col, ls, lw] = flowStyle(S.Inputs(outI(k)).DataType);
        plot(S.AxMap, [x x], [yB-0.02 yB-0.20], 'LineStyle',ls,'Color',col,'LineWidth',lw, ...
             'ButtonDownFcn',@(s,e) rtlca_system('onFlowClick',s,e),'UserData',outI(k),'PickableParts','all');
        patch(S.AxMap, [x-0.025 x+0.025 x], [yB-0.19 yB-0.19 yB-0.24], col, 'EdgeColor',col, ...
              'ButtonDownFcn',@(s,e) rtlca_system('onFlowClick',s,e),'UserData',outI(k),'PickableParts','all');
        text(S.AxMap, x, yB-0.26, flowLabel(S.Inputs(outI(k))), 'Rotation',-60, ...
             'HorizontalAlignment','left','VerticalAlignment','middle', ...
             'FontSize',8,'Color',col,'Interpreter','none', ...
             'ButtonDownFcn',@(s,e) rtlca_system('onFlowClick',s,e),'UserData',outI(k));
    end
end
S.AxMap.XLim = [0.4 nP+0.6]; S.AxMap.YLim = [-0.30 1.85];
set(S.AxMap,'XTick',[],'YTick',[],'XColor','w','YColor','w','Box','off');
title(S.AxMap,'Unit processes (flow order) - click a block or an arrow to inspect/edit - RT blue, static grey, quasi-static dashed, dynamic dash-dot');
setappdata(fig,'S',S);
end


function [col, ls, lw] = flowStyle(dt)
switch dt
    case 'real-time',    col = [0.13 0.45 0.71]; ls = '-';  lw = 2.2;
    case 'static',       col = [0.40 0.40 0.40]; ls = '-';  lw = 1.4;
    case 'quasi-static', col = [0.40 0.40 0.40]; ls = '--'; lw = 1.4;
    otherwise,           col = [0.55 0.30 0.65]; ls = '-.'; lw = 1.4;
end
end


function lab = flowLabel(in)
if strcmp(in.DataType,'real-time'), q = 'energy RT';
elseif strcmp(in.DataType,'dynamic'), q = 'v(t)';
elseif isnan(in.Qty), q = '-';
else, q = sprintf('%.3g %s', in.Qty, in.Unit); end
lab = sprintf('%s (%s)', rtlca_util('trunc', in.Nome,16), q);
end


% #########################################################################
%  STEP 3: FLOWS (taxonomy, direction, dynamic law asked immediately)
% #########################################################################


